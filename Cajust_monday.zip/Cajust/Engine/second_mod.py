# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 11:14:34 2019

@author: tanmay.sidhu
"""
import first_mod
print("This is second Module")