# -*- coding: utf-8 -*-
"""
Created on Fri Aug 30 15:36:45 2019

@author: Tanmay.Sidhu
"""

import pandas as pd



CLOSE=pd.ExcelFile("EVS_MLFPSCET_OC_20190828.xls").parse(sheet_name="CLOSE",header=0)
OPEN=pd.ExcelFile("EVS_MLFPSCET_OC_20190828.xls").parse(sheet_name="OPEN",header=0)

CLOSE=CLOSE.rename(columns={"DATE":"close.DATE","FIGI":"close.FIGI","BBG":"close.BBG","TICKER":"close:TICKER","CCY":"close:CCY","FX":"close:FX","PRICE LOCAL":"close.PRICE LOCAL","PRICE INDEX":"close.INDEX","UNIT WEIGHT":"close.UNIT WEIGHT","LINE VALUE":"close.LINE VALUE","VALUE":"close.VALUE","DIVISOR":"close.DIVISOR","INDEX LEVEL":"close.INDEX LEVEL","PERCENT WEIGHT":"close.PERCENT WEIGHT"})


OPEN=OPEN.rename(columns={"DATE":"open.DATE","REBAL FLAG":"open.REBEL FLAG","FIGI":"open.FIGI","BBG TICKER":"open.BBG TICKER"	,"CCY":"open.CCY","FX":"open:FX","PRICE LOCAL":"open.PRICE LOCAL","PRICE INDEX":"open.PRICE INDEX","NDN":"open.NDN","LINE VALUE":"open.LINE VALUE","NDD":"open.NDD","CA FLAG":"open.CA FLAG","UNIT WEIGHT":"open.UNIT WEIGHT","DELTA CAP":"open.DELTA CAP","TOTAL ADJUSTMENTS":"open.TOTAL ADJUSTMENTS","DIVISOR":"open.DIVISOR"})
#FIGI	BBG TICKER	CCY	FX	PRICE LOCAL	PRICE INDEX	NDN	LINE VALUE	NDD	CA FLAG	UNIT WEIGHT	DELTA CAP	TOTAL ADJUSTMENTS	DIVISOR

#DATE	FIGI	BBG TICKER	CCY	FX	PRICE LOCAL	PRICE INDEX	UNIT WEIGHT	LINE VALUE	DIVISOR	INDEX LEVEL	PERCENT WEIGHT

final = pd.concat([CLOSE, OPEN], axis=1, sort=False)
