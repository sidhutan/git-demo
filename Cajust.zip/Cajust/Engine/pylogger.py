# -*- coding: utf-8 -*-
"""
Created on Tue May 14 11:13:53 2019

@author: tanmay.sidhu
"""
import pandas as pd
import logging
import getpass

def loggy():
    #move it to core_var
    username=getpass.getuser()
    logfile=r'C:/Users/'+username+"/Documents/Cajust/logs/log_"+(pd.datetime.today().strftime("%Y_%m_%d"))+".txt"
    logfile_format="%(asctime)s %(module)s %(funcName)s %(levelname)s %(lineno)d -%(message)s"    
    #if changing log file config, restart of kernal is required
    #setting up logging system using basic config
    logging.basicConfig(filename=logfile,level=logging.DEBUG,format=logfile_format)
    #creating and initiating a logger object using getLogger
    logger=logging.getLogger()
#    logger.info("Info Statement")
#    logger.debug("Debug statement")
#    logger.warning("Warning statement")
#    logger.error("Error statement")
#    logger.critical("Critical statement")
    return logger



#loggy()