# -*- coding: utf-8 -*-
"""
Created on Wed May  8 10:36:28 2019

@author: tanmay.sidhu
"""


import pandas as pd
import mysql.connector as mariadb
print("here")
def DB_connect(query):  
    mariadb_connection=mariadb.connect(host='evs01cpa008', user='root', password='cajust1234', database='cajust')
    cursor=mariadb_connection.cursor()
#    cursor.execute(query)
    try:
        cursor.execute(query)
#        cursor.execute('select A.UserName,B.EventName,C.CountryCode,D.Taxrate,X.* from cainput as X join causer as A on A.UserId = X.UserId join eventtypemaster as B on B.eventtypeid = x.eventtypeid join countrymaster as C on C.CountryId = x.countryid join countrytaxrate_wht as D on D.CountryID = X.CountryId')
    except mariadb.Error as error:
        print("Error{}".format(error))
    sql_data=pd.DataFrame(cursor.fetchall())
   
    sql_data.columns=cursor.column_names
#    sql_data.to_csv("db.csv")
    cursor.close()
    return sql_data



#DB_connect()
#cursor.execute ("UPDATE factset.output SET IndexLevel=%s WHERE CalDate=%s",data["Index_Series"].tail(1),current_date.strftime("%Y-%m-%d"))
