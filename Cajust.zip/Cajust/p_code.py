# -*- coding: utf-8 -*-
"""
Created on Mon Aug  5 16:49:08 2019

@author: tanmay.sidhu
"""

import pandas as pd
import datetime as dt
import win32com.client as win32
outlook=win32.Dispatch("Outlook.Application").GetNamespace("MAPI")
inbox=outlook.GetDefaultFolder("6")
all_inbox=inbox.Items

for i in list(all_inbox)[:50]:
    print(i.Subject)



class demo:
    def check(self,a):
        if a=="yes":
            print("yes")
        elif a=="no":
            print("no")

b=demo()
b.check("yes")