# -*- coding: utf-8 -*-
"""
Created on Sun Sep  1 14:07:07 2019

@author: Tanmay.Sidhu
"""

import coredivRule
import pandas as pd
import DB_connect
import pylogger
logA=pylogger.loggy()
def db_entries(df,kind=None):
    df=df.loc[:,~df.columns.str.contains('^Unnamed')]
    if kind=="CD":
        logA.info("Inside Db Entries : CD")
#        df=df.fillna(0)
        df=df[["CAReqDetailID","Div_GTR_PAF","Div_NTR_PAF","Div_PR_PAF","Div_NSAF","SCR_GTR_NSAF","SCR_NTR_NSAF","SCR_PR_NSAF","SCR_PAF","AddC_GTR_CASH","AddC_NTR_CASH","AddC_PR_CASH","Handled_on_PayDate","Multiple_Case"]]
        df=df.fillna(0)
        df_list=[]
        df.to_csv("tanmay_CD.csv")
        for index, rows in df.iterrows():    
        # Create list for the current row
            my_list =[rows.CAReqDetailID, rows.Div_GTR_PAF, rows.Div_NTR_PAF,rows.Div_PR_PAF,rows.Div_NSAF,rows.SCR_GTR_NSAF,rows.SCR_NTR_NSAF,rows.SCR_PR_NSAF,rows.SCR_PAF,rows.AddC_GTR_CASH,rows.AddC_NTR_CASH,rows.AddC_PR_CASH,rows.Handled_on_PayDate,rows.Multiple_Case] 
            df_list.append(my_list)
#        df_list=df.values.tolist()
#        "Div_NTR_PAF","Div_GTR_PAF","Div_PR_PAF","Div_NSAF","SCR_GTR_NSAF","SCR_NTR_NSAF","SCR_PR_NSAF","SCR_PAF","AddC_GTR_CASH","AddC_NTR_CASH","AddC_PR_CASH","Handled_on_PayDate","Multiple_Case"
        query="INSERT INTO cajust.ca_req_outputdetails(CaReqDetailID,Div_GTR_PAF,Div_NTR_PAF,Div_PR_PAF,Div_NSAF,SCR_GTR_NSAF,SCR_NTR_NSAF,SCR_PR_NSAF,SCR_PAF,AddC_GTR_CASH,AddC_NTR_CASH,AddC_PR_CASH,Handled_on_PayDate,Multiple_Case) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
        DB_connect.DB_connect_many(query,df_list)
    elif kind=="multiple":
        print("WE are in multiple",df)
        logA.info("Inside Db Entries : multiple")
        df=df[["CAReqDetailID","Div_GTR_PAF","Div_NTR_PAF","Div_PR_PAF","Div_NSAF","SCR_GTR_NSAF","SCR_NTR_NSAF","SCR_PR_NSAF","SCR_PAF","AddC_GTR_CASH","AddC_NTR_CASH","AddC_PR_CASH","Handled_on_PayDate","Multiple_Case"]]
        df=df.fillna(0)
        df_list=[]
        df.to_csv("tanmay_multi.csv")
        for index,rows in df.iterrows():
            my_list=[rows.CAReqDetailID,rows.Div_GTR_PAF,rows.Div_NTR_PAF,rows.Div_PR_PAF,rows.Div_NSAF,rows.SCR_GTR_NSAF,rows.SCR_NTR_NSAF,rows.SCR_PR_NSAF,rows.SCR_PAF,rows.AddC_GTR_CASH,rows.AddC_NTR_CASH,rows.AddC_PR_CASH,rows.Handled_on_PayDate,rows.Multiple_Case]
            df_list.append(my_list)
        query="Insert into ca_req_OUTPUTdetails(CAReqDetailID,Div_GTR_PAF,Div_NTR_PAF,Div_PR_PAF,Div_NSAF,SCR_GTR_NSAF,SCR_NTR_NSAF,SCR_PR_NSAF,SCR_PAF,AddC_GTR_CASH,AddC_NTR_CASH,AddC_PR_CASH,Handled_on_PayDate,Multiple_Case)  VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
#        df_list=df.values.tolist()
        print("df_list",df_list)
        DB_connect.DB_connect_many(query,df_list)
    elif kind=="others":
        df_list=[]
        print("In others DB")
        logA.info("Inside Db Entries : others")
        df.to_csv("tanmay_others.csv")
        df=df.fillna(0)
        df=df[["CAReqDetailID","Div_PAF","Div_NSAF","SCR_NSAF","Handled_on_PayDate","Multiple_Case"]]
#        df_list=df.values.tolist()
        for index,rows in df.iterrows():
            mylist=[rows.CAReqDetailID,rows.Div_PAF,rows.Div_NSAF,rows.SCR_NSAF,rows.Handled_on_PayDate,rows.Multiple_Case]
            df_list.append(mylist)
#        print("df_list",df_list)

        query="INSERT INTO cajust.ca_req_outputdetails(CaReqDetailID,Div_PAF,Div_NSAF,SCR_NSAF,Handled_on_PayDate,Multiple_Case) VALUES(%s,%s,%s,%s,%s,%s)"
        DB_connect.DB_connect_many(query,df_list)
if __name__=="__main__":
    f_df=pd.DataFrame()
    obj_process=coredivRule.rule_divisor()
    obj_events=obj_process.nd_event_types()
    
    try:
        multi_handled_CA=obj_process.multi_CA_handler()
        logA.info("Database Entries: Multi case data preparation : Done")
        db_entries(multi_handled_CA,kind="multiple")
        logA.info("Database Entries: Multi case data insertion status: SUCCESS")
        if "Cash Dividend" in obj_events:
            #take the hard coded values from database's eventtype master table
            obj_process.cash_dividend()
            logA.info("Database Entries: CD settlement preparation : Done")
            if "Special Cash Dividend" not in obj_events:
                f_df=f_df.append(obj_process.sql_cash_div_ex_excep,sort=False)
                f_df=f_df.append(obj_process.sql_cash_div_except,sort=False)
                f_df=f_df.append(obj_process.nd_final_combinedPay,sort=False)
                db_entries(f_df,kind="CD")
                logA.info("Database Entries: CD,SP and Paydate settlement : Done")
        if "Special Cash Dividend" in obj_events:
            logA.info("Database Entries: CD,SP and Paydate settlement preparation : Done")
            obj_process.special_cash_dividend()
            f_df=f_df.append(obj_process.sql_cash_div_ex_excep,sort=False)
            f_df=f_df.append(obj_process.sql_cash_div_except,sort=False)
            f_df=f_df.append(obj_process.nd_final_combinedPay,sort=False)
            db_entries(f_df,kind="CD")
            logA.info("Database Entries: CD,SP and Paydate settlement insertion : SUCCESS")
        if "Stock Dividend" in obj_events:
            obj_process.stock_dividend()
        if "Stock Split" in obj_events:
            obj_process.stock_split()
        if "Rights Issue" in obj_events:
            obj_process.rights_issue()
        if "Spin Off" in obj_events:
            obj_process.spin_off()
        db_entries(obj_process.sql_others,kind="others")
        logA.info("Database Entries: Non cash Corporate actions insertion: SUCCESS")
    except Exception as e:
        print("Error_{}".format(e))
        logA.error("Issue with Processorcaller")
        pass
        
    