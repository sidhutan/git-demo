# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 11:33:08 2019

@author: tanmay.sidhu
"""

# -*- coding: utf-8 -*-
"""
Created on Mon May 13 10:36:20 2019

@author: tanmay.sidhu
"""
import pylogger
logA=pylogger.loggy()
from core_var import conf
import pandas as pd
class rule_divisor(conf):
    """This is for Divisor based Methodlogy"""

    def __init__(self):
        "Initialising all the variables used in this Divisor class"
        try:
            super().__init__()
            print("Inside rule divisor init")
            logA.info("Divisor is INITIATED")
            logA.info("Divisor Initiation is SUCCESFULLY done")
        except:
            logA.error("Divisor Initialisation has FAILED")
#    def fn_master(self,df,col1,col1_event,col2,col2_event):
#        self.df.loc[(self.df[col1].isin([i for i in col1_event]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"PriceExT1"]
        
    def fn_cash_ex_excep(self,event_type,eventvalue):
        """Just a func to have a clean code Structure"""
        return self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin([event_type]),eventvalue]

    def fn_s_cash_ex_excep(self,event_type,eventvalue):
         """Just a func to have a clean code Structure"""
         return self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin([event_type]),eventvalue]
    def fn_s_cash_excep(self,event_type,eventvalue):
         return self.sql_cash_div_except.loc[self.sql_cash_div_except["EventType"].isin([event_type]),eventvalue]
    def fn_handling_multiple(self,df1):
        print(">>>>>>>>>>>>>>>>>>",df1)
        
        """Handling sequence """
        #cash Dividend
        #Stock Dividend
        #stock Split
        #rights issue
        #spin off
        if df1=="pay":
            counter=0
            """Only Cash and  Dividend"""
            df_pay=self.d_final_combinedPay.groupby("CombinedPay")
            for i in list(df_pay.groups):
                grp_name=i
                i=df_pay.get_group(i)
                print("grp_name_pay",grp_name)
                if len(i.loc[i["EventType"].isin(["Cash Dividend"])])>0:
                    counter=counter+1
                    if i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"]).isin(["JP","KR"]),"EventType"].count() > 0:
                        jp_kr_PriceExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PriceExT1"]
                        jp_kr_FxExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"FxExT1"]
                        jp_kr_TaxRate=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"TaxRate"]
                        jp_kr_event_amount=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"EventAmount"].sum()
#                        print("dem",(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1)
                        GTR_PAF= (jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1                       
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"GTR(PAF)"]=GTR_PAF
                        NTR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1)*(jp_kr_TaxRate/100))/jp_kr_PriceExT1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NTR(PAF)"]=NTR_PAF
                        PR_PAF=1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PR(PAF)"]=PR_PAF
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NSAF"]=1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"GTR_PriceExT1"]=jp_kr_PriceExT1*GTR_PAF
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NTR_PriceExT1"]=jp_kr_PriceExT1*NTR_PAF
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PR_PriceExT1"]=jp_kr_PriceExT1*PR_PAF
                    if i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"]).isin(["JP","KR"]),"EventType"].count() > 0:
                        if counter>0:
                            jp_kr_PriceExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PriceExT1"]
                        else:
                            jp_kr_PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PriceExT1"]
                        jp_kr_FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"FxExT1"]
                        jp_kr_TaxRate=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"TaxRate"]
                        jp_kr_event_amount=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"EventAmount"].sum()
                        GTR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"GTR(PAF)"]=GTR_PAF
                        NTR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NTR(PAF)"]=NTR_PAF
                        PR_PAF=1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PR(PAF)"]=PR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NSAF"]=1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"GTR_PriceExT1"]=jp_kr_PriceExT1*GTR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NTR_PriceExT1"]=jp_kr_PriceExT1*NTR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PR_PriceExT1"]=jp_kr_PriceExT1*PR_PAF
                        
        if df1=="ex":
            counter=0
            df_ex=self.d_final_combinedEx.groupby('CombinedEx')
#            print(type(df_ex))
#            print(df_ex)
            for i in list(df_ex.groups):
#                print("groups",list(df_ex.groups))
#                print("yo!",i)
                grp_name=i
                i=df_ex.get_group(i)
                print("grp_name_ex",i)
#                i.to_csv("i1.csv")
                print("lets_ check",len(i.loc[(i['EventType'].isin(['Special Cash Dividend']))]))
                if len(i.loc[i["EventType"].isin(['Cash Dividend'])]) > 0:
                    logA.info("Inside duplicates: Cash Dividend")
                    counter=counter+1
                    i["Counter"]=""
                    print("Inside duplicates: Cash Dividend")
                    if i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"EventType"].count() > 0:
                        logA.info("Inside duplicates: Cash Dividend_AU")
                        i.loc[(i["EventType"].isin(['Cash Dividend']))&(i["LocalCurrency"].isin(["AU"])),"Counter"]=counter
                        au_PriceExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                        au_Fx_1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"FxExT1"]
                        au_TaxRate=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"TaxRate"]
                        Frank_Percent=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"FrankingPercent"]
                        Income_dis_percent=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"IncomePercent"]
                        Ef_TaxRate=au_TaxRate*(1 - Frank_Percent - Income_dis_percent)
                        au_EventAmount=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"EventAmount"]
                        Ef_EventAmount=au_EventAmount(1-Ef_TaxRate)
                        Div_GTR_PAF=(au_PriceExT1-(au_EventAmount*au_Fx_1))/au_PriceExT1
                        Div_NTR_PAF=(au_PriceExT1-(Ef_EventAmount*au_Fx_1))/au_PriceExT1 
                        i.loc[i["LocalCurrency"].isin(["AU"])&(i["EventType"].isin(["Cash Dividend"])),"Div_GTR_PAF"]=Div_GTR_PAF
                        i.loc[i["LocalCurrency"].isin(["AU"])&(i["EventType"].isin(["Cash Dividend"])),"Div_NTR_PAF"]=Div_NTR_PAF
                        i.loc[i["LocalCurrency"].isin(["AU"])&(i["EventType"].isin(["Cash Dividend"])),"Div_PR_PAF"]=1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_NSAF"]=1
                        aus_adj_price_NTR=Div_NTR_PAF*au_PriceExT1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"NTR_PriceExT1"]=aus_adj_price_NTR
                        aus_adj_price_GTR=Div_GTR_PAF*au_PriceExT1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"GTR_PriceExT1"]=aus_adj_price_GTR
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PR_PriceExT1"]=au_PriceExT1*1
#                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_GTR_UAF"]=
#                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_NTR_UAF"]=
#                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_PR_UAF"]=
                        logA.info("Multiple CA of Exceptional cases is SUCESSFULLY completed")
                    if len(i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU']))]) > 0:
                        
                        logA.info("Inside duplicates: cash dividend other than AU")
                        if type(max(i["Counter"]))=="str":
                            PriceExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                            EventAmount=i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i["LocalCurrency"].isin(['AU'])),"EventAmount"]
                            FxExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"FxExT1"]
                            TaxRate=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"TaxRate"]
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1) / PriceExT1)
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                            Div_PR_PAF=1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NSAF"]=1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"SCR_GTR_UAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"SCR_NTR_UAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100)))
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"SCR_PR_UAF"]=1
                            GTR_PriceExT1=PriceExT1*Div_GTR_PAF
                            NTR_PriceExT1=PriceExT1*Div_NTR_PAF
                            PR_PriceExT1=PriceExT1*Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"GTR_PriceExT1"]=GTR_PriceExT1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"NTR_PriceExT1"]=NTR_PriceExT1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"PR_PriceExT1"]=PR_PriceExT1
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                        else:
                            GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"]
                            NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"]
                            PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"]
                            FxExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"FxExT1"]
                            TaxRate=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"TaxRate"]
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                            Div_PR_PAF=1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            adj_price_GTR=Div_GTR_PAF*GTR_PriceExT1
                            adj_price_NTR=Div_NTR_PAF*NTR_PriceExT1
                            adj_price_PR=Div_PR_PAF*PR_PriceExT1
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"GTR_PriceExT1"]=adj_price_GTR
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"NTR_PriceExT1"]=adj_price_NTR
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"PR_PriceExT1"]=adj_price_PR
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
#                        i.to_csv("i.csv")

                if len(i.loc[(i['EventType'].isin(['Special Cash Dividend']))]) > 0:
                    print("Inside duplicates: special cash")
                    counter=counter+1
                    i.loc[(i['EventType'].isin(['Special Cash Dividend'])),"Counter"]=counter
                    if i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"EventType"].count() > 0:
                        if type(max(i["Counter"]))=="str":
                            print("Inside duplicates: special cash_AU")
#                            SA_PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                            PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                            EventAmount=i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(i["LocalCurrency"].isin(['AU'])),"EventAmount"]
                            FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"FxExT1"]
                            TaxRate=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"TaxRate"]
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1) / PriceExT1)
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                            Div_PR_PAF=1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_NSAF"]=1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_GTR_UAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_NTR_UAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100)))
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_PR_UAF"]=1
                            GTR_PriceExT1=PriceExT1*Div_GTR_PAF
                            NTR_PriceExT1=PriceExT1*Div_NTR_PAF
                            PR_PriceExT1=PriceExT1*Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"GTR_PriceExT1"]=GTR_PriceExT1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"NTR_PriceExT1"]=NTR_PriceExT1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PR_PriceExT1"]=PR_PriceExT1
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                        else:
#                            GTR_PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"GTR_PriceExT1"].values[0]
                            GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"]
                            NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"]
                            PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"]
                            FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"FxExT1"]
                            TaxRate=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"TaxRate"]
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                            Div_PR_PAF=1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            adj_price_GTR=Div_GTR_PAF*GTR_PriceExT1
                            adj_price_NTR=Div_NTR_PAF*NTR_PriceExT1
                            adj_price_PR=Div_PR_PAF*PR_PriceExT1
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"GTR_PriceExT1"]=adj_price_GTR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"NTR_PriceExT1"]=adj_price_NTR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"PR_PriceExT1"]=adj_price_PR
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                if len(i.loc[i["EventType"].isin(["Stock Dividend"])]) > 0:
                    counter=counter+1
                    i.loc[i["EventType"].isin(["Stock Dividend"]),"Counter"]=counter
                    TermNewShares=i.loc[(i["EventType"].isin(["Stock Dividend"],"TermNewShares"))]
                    TermOldShares=i.loc[(i["EventType"].isin(["Stock Dividend"],"TermOldShares"))]
                    m=TermNewShares/TermOldShares
                    PAF=1/1+m
                    NSAF=1+m
                    i.loc[i["EventType"].isin(["Stock Dividend"]),"Div_PAF"]=PAF
                    i.loc[i["EventType"].isin(["Stock Dividend"]),"Div_NSAF"]=NSAF
                    i.loc[i["EventType"].isin(["Stock Dividend"]),"SCR_NSAF"]=NSAF
#                    i.loc[i["EventType"].isin(["Stock Dividend"],"Counter")]=counter
                    if type(max(i["Counter"]))!="str":
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"]*PAF
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"]*PAF
                        PR_PriceExT1==i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"]*PAF
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"GTR_PriceExT1"]=GTR_PriceExT1
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"NTR_PriceExT1"]=NTR_PriceExT1
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"PR_PriceExT1"]=PR_PriceExT1
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"NSAF"]=1-m
                if len(i.loc[i["EventType"].isin(["Stock Split"])]) > 0:
                    counter=counter+1
                    i.loc[i["EventType"].isin(["Stock Split"]),"Counter"]=counter
                    TermNewShares=i.loc[i["EventType"].isin(["Stock Split"]),"TermNewShares"]
                    TermOldShares=i.loc[i["EventType"].isin(["Stock Split"]),"TermOldShares"]
                    m=TermNewShares/TermOldShares
                    i.loc[i["EventType"].isin(["Stock Split"]),"NSAF"]=m
                    PAF=1/m
                    i.loc[i["EventType"].isin(["Stock Split"]),"Div_PAF"]=PAF
                    i.loc[i["EventType"].isin(["Stock Split"]),"Div_NSAF"]=m
                    i.loc[i["EventType"].isin(["Stock Split"]),"SCR_NSAF"]=m
                    i.loc[i["EventType"].isin(["Stock Split"]),"Counter"]=counter
                    if type(max(i["Counter"]))!="str":
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"]*PAF
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"]*PAF
                        PR_PriceExT1==i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"]*PAF
                        i.loc[i["EventType"].isin(["Stock Split"]),"GTR_PriceExT1"]=GTR_PriceExT1
                        i.loc[i["EventType"].isin(["Stock Split"]),"NTR_PriceExT1"]=NTR_PriceExT1
                        i.loc[i["EventType"].isin(["Stock Split"]),"PR_PriceExT1"]=PR_PriceExT1
                        
                if len(i.loc[i["EventType"].isin(["Rights Issue"])]) > 0:
                    counter=counter+1
                    i.loc[i["EventType"].isin(["Rights Issue"]),"Counter"]=counter
                    PriceExT1=i.loc[i["EventType"].isin(["Rights Issue"]),"PriceExT1"]
                    TermNewShares=i.loc[(i["EventType"].isin(["Rights Issue"],"TermNewShares"))]
                    TermoldShares=i.loc[(i["EventType"].isin(["Rights Issue"],"TermOldShares"))]
                    m=TermNewShares/TermoldShares
                    offerprice=i.loc[(i["EventType"].isin(["Rights Issue"])),"OfferPrice"]
                    PAF=(PriceExT1+(m*offerprice))/PriceExT1*(1-m)
                    i.loc[i["EventType"].isin(["Rights Issue"]),"NSAF"]=1+m
                    if type(max(i["Counter"]))!="str":
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"]*PAF
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"]*PAF
                        PR_PriceExT1==i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"]*PAF
                        i.loc[i["EventType"].isin(["Rights Issue"]),"GTR_PriceExT1"]=GTR_PriceExT1
                        i.loc[i["EventType"].isin(["Rights Issue"]),"NTR_PriceExT1"]=NTR_PriceExT1
                        i.loc[i["EventType"].isin(["Rights Issue"]),"PR_PriceExT1"]=PR_PriceExT1
                    
                    """Need to include the NSAF"""
                            #no spin off cases
                if len(i["EventType"].isin(["Spin off"])) >0:                    
                    PriceExT1=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"PriceExT1"]
                    cash=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"SpunOffCash"]
                    spun_entity_openprices=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"OfferPrice"]
                    newshares=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"TermNewShares"]
                    oldshares=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"TermOldShares"]
                    m=newshares/oldshares
                    PAF_spin=(PriceExT1-cash-m*spun_entity_openprices)/PriceExT1
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"Div_PAF"]=PAF_spin
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"Div_NSAF"]=1
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"SCR_UAF"]=1
                    if type(max(i["Counter"]))!="str":
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"]*PAF_spin
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"]*PAF_spin
                        PR_PriceExT1==i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"]*PAF_spin
                        i.loc[i["EventType"].isin(["Spin-off"]),"GTR_PriceExT1"]=GTR_PriceExT1
                        i.loc[i["EventType"].isin(["Spin-off"]),"NTR_PriceExT1"]=NTR_PriceExT1
                        i.loc[i["EventType"].isin(["Spin-off"]),"PR_PriceExT1"]=PR_PriceExT1
                        
                        
                print("mutli CA",i.loc[i["Counter"]==max(i["Counter"]),"PriceExT1"].values[0])
                closeprice=i.loc[i["Counter"]==max(i["Counter"]),"PriceExT1"]
                adj_GTR_price=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"]
                adj_NTR_price=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"]
                adj_PR_price=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"]
#                i.to_csv("i.csv")
                df = pd.DataFrame(columns=["PR_PAF","GTR_PAF","Div_NTR_PAF","PR_SAF","GTR_SAF","NTR_SAF"])
                if closeprice==adj_GTR_price:
                    print("final_1")
                    df.loc[grp_name,"GTR_PAF"] = 1
                    df.loc[grp_name,"NSAF"]=i.loc["Div_NSAF"].prod()
    #                df.loc[df[i]=="GTR","PAF"] = 1
                else:
                    print("final_2")
                    df.loc[grp_name,"GTR_PAF"]=adj_GTR_price/closeprice
                    df.loc[grp_name,"NSAF"]=i.loc["NSAF"].prod()
#                    df.loc[grp_name,"SAF"]=
    #                df.loc[df["TYPE"]=="GTR","PAF"] = adj_GTR_price/closeprice
                if closeprice== adj_NTR_price:
                    print("final_3")
                    df.loc[grp_name,"NTR_PAF"]=1
                    df.loc[grp_name,"NSAF"]=i.loc["NSAF"].prod()
    #                df.loc[df["TYPE"]=="NTR","PAF"] = 1
                else:
                    print("final_4")
                    df.loc[grp_name,"NTR_PAF"]=adj_NTR_price/closeprice
                    df.loc[grp_name,"NSAF"]=i.loc["NSAF"].prod()
    #                df.loc[df["TYPE"]=="NTR","PAF"] = adj_NTR_price/closeprice
                if closeprice== adj_NTR_price:
                    print("final_2")
                    df.loc[grp_name,"PR_PAF"]=1
                    df.loc[grp_name,"NSAF"]=i.loc["NSAF"].prod()
    #                df.loc[df["TYPE"]=="PR","PAF"] = 1
                else:
                    df.loc[grp_name,"PR_PAF"]=adj_PR_price/closeprice
                    df.loc[grp_name,"NSAF"]=i.loc["NSAF"].prod()
    #                df.loc[df["TYPE"]=="PR","PAF"] = adj_PR_price/closeprice
                df.to_csv("df.csv")                 
                                            
                                        
                            
                        
                    
                                   
                        
                    
                        
                        
                        
                                       
                        
                        
                        
    
        

#""" CA adjustment function"""
#
#
#def CA_adjust(current_date, next_opendate, prerebaldate):
#    global df_input_CAo_required1
#    global df_mapping
#    global df_rebal_details
#    global data
#    
#    
#    columns = "2595708"
#    for columns in df_rebal_details["SEDOL-CHK"][df_rebal_details.index == prerebaldate]:
#        
#                if (df_mapping.loc[columns,"RIC"] in np.array(df_input_CAo_required1["RIC"])):
#                    df_input_CAo_required = df_input_CAo_required1[df_input_CAo_required1["RIC"]==df_mapping.loc[columns,"RIC"]]
#                    
#                    if not len(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Delisting"]) == 0:
#                        data["Adj_units"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = 0
#                        
#                    if not len(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Cash Dividend"]) == 0:
#                        #Get Currency of CA
#                        curncy = df_input_CAo_required[df_input_CAo_required["Action Type"]=="Cash Dividend"]["Currency"]
#                        mthd = data["Conversion_methodology"].loc[curncy,:]
#                        if mthd.iloc[0,1] == "inverse":
#                            data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float((data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] - (df_input_CAo_required[df_input_CAo_required["Action Type"]=="Cash Dividend"]["Gross Amount"] / fx_rate.loc[mthd["Ticker"],"Spot Rate"].values/mthd.iloc[0,2]).values))
#                        elif mthd.iloc[0,1] == "multiply":
#                            data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float((data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] - (df_input_CAo_required[df_input_CAo_required["Action Type"]=="Cash Dividend"]["Gross Amount"] * fx_rate.loc[mthd["Ticker"],"Spot Rate"].values/mthd.iloc[0,2]).values))
#
#                    
#                    if not len(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Stock Dividend"]) == 0:
#                        data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float((data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]/np.array(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Stock Dividend"]["Gross Amount"])))
#                        data["Adj_units"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float((data["Adj_units"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]*np.array(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Stock Dividend"]["Gross Amount"])))
#                    
#                    if not len(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Stock Split"]) == 0:
#                        data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float((data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]/np.array(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Stock Split"]["Gross Amount"])))
#                        data["Adj_units"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float((data["Adj_units"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]*np.array(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Stock Split"]["Gross Amount"])))
#                    
#                    if not len(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]) == 0:
#                        curncy = df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]["Currency"]
#                        mthd = data["Conversion_methodology"].loc[curncy,:]                                                  
#                        if mthd.iloc[0,1] == "inverse":
#                            data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float(np.array((data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]+(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]["Subscription Price"]/mthd.iloc[0,2]/fx_rate.loc[mthd["Ticker"],"Spot Rate"].values*df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]["Gross Amount"]))/(1+df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]["Gross Amount"])))
#                        elif mthd.iloc[0,1] == "multiply":
#                            data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float(np.array((data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]+(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]["Subscription Price"]/mthd.iloc[0,2]*fx_rate.loc[mthd["Ticker"],"Spot Rate"].values*df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]["Gross Amount"]))/(1+df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]["Gross Amount"])))
#                        
#                        data["Adj_units"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float(np.array(data["Adj_units"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]*(1+df_input_CAo_required[df_input_CAo_required["Action Type"]=="Rights Offerings"]["Gross Amount"])))
#                    
#                    if not len(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Spin-off"]) == 0:
#                        curncy = df_input_CAo_required[df_input_CAo_required["Action Type"]=="Spin-off"]["Currency"]
#                        mthd = data["Conversion_methodology"].loc[curncy,:]                                                  
#                        if mthd.iloc[0,1] == "inverse":
#                            data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float(np.array((data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]-(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Spin-off"]["Subscription Price"]*df_input_CAo_required[df_input_CAo_required["Action Type"]=="Spin-off"]["Gross Amount"] / fx_rate.loc[mthd["Ticker"],"Spot Rate"].values /mthd.iloc[0,2]))))    
#                        elif mthd.iloc[0,1] == "multiply":
#                            data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]] = float(np.array((data["Adj_px"].loc[next_opendate,df_mapping.loc[columns,"RIC"]]-(df_input_CAo_required[df_input_CAo_required["Action Type"]=="Spin-off"]["Subscription Price"]*df_input_CAo_required[df_input_CAo_required["Action Type"]=="Spin-off"]["Gross Amount"] * fx_rate.loc[mthd["Ticker"],"Spot Rate"].values /mthd.iloc[0,2]))))
#"""Function end"""
#   
    def multi_CA_handler(self):
        if (self.d_final_combinedEx is not None) or (not self.d_final_combinedEx.empty):
            print("Dupli",1)
            self.fn_handling_multiple("ex")
        if (self.d_final_combinedPay is not None) or (not self.d_final_combinedPay.empty):
            print("Dupli",2)
            self.fn_handling_multiple("pay")
            
        
    def cash_dividend(self):
        """Calculation of PAF for Cash Dividend"""
        try:#CHANGE Country CODE to currency HERE"""
            """First Handling cash dividend for exceptional cases
                Second Handling cash dividend for non exceptional cases
                Third Handling cash dividend for pay date exceptional cases """
        #Handling of AuSCRalian stock security
            if self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"EventType"].count() > 0:
#                print("testing",self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"]))].count())
                logA.info(" First Cash Dividend for exceptional cases Calculation is INITIATED")
                """CHANGE Country CODE to currency HERE"""
                au_PriceExT1=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                logA.info("Inside Cash divi_AU {}".format(au_PriceExT1))
                au_Fx_1=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"FxExT1"]
                logA.debug("Value of Au_FX_1= {} ".format(au_Fx_1))
                au_TaxRate=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"TaxRate"]
                print("Tax",au_TaxRate)
#                self.sql_cash_div_except.to_csv("waah.csv")
                logA.debug("Value of au_TaxRate= {} ".format(au_TaxRate))
                Frank_Percent=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"FrankingPercent"]
                logA.debug("Value of Frank_Percent= {} ".format(Frank_Percent))
                Income_dis_percent=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"IncomePercent"]
                logA.debug("Value of Income_dis_percent= {} ".format(Income_dis_percent))
                Ef_TaxRate=(au_TaxRate/100)*(1 - Frank_Percent - Income_dis_percent)
                logA.debug("Value of Ef_TaxRate= {} ".format(Ef_TaxRate))
                au_EventAmount=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"EventAmount"]
                logA.debug("Value of au_EventAmount= {} ".format(au_EventAmount))
#                self.sql_cash_div_except.to_csv("AU_check.csv")
                Ef_EventAmount=au_EventAmount*(1-Ef_TaxRate)
                logA.debug("Value of Ef_EventAmount= {} ".format(Ef_EventAmount))
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Div_GTR_PAF"]=(au_PriceExT1-(au_EventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Div_NTR_PAF"]=(au_PriceExT1-(Ef_EventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Div_PR_PAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Div_NSAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"SCR_GTR_UAF"]=(au_PriceExT1)/(au_PriceExT1-(au_EventAmount*au_Fx_1))
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"SCR_NTR_UAF"]=(au_PriceExT1)/(au_PriceExT1-(Ef_EventAmount*au_Fx_1))
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"SCR_NTR_PAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"AddC_GTR_CASH"]=au_EventAmount*au_Fx_1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"AddC_NTR_CASH"]=Ef_EventAmount*au_Fx_1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"AddC_PR_CASH"]=0
                logA.info("First Cash Dividend for exceptional cases Calculation is SUCCESFULLY done")
                    
            else:
                logA.info("First Cash Dividend for exceptional cases Calculation: NO RECORDS FOUND")
        except Exception as e:
            logA.error(e)
            logA.error("First Cash Dividend for exceptional cases Calculation has FAILED")
        try:
            if self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"EventType"].count() > 0:
                logA.info("Second Cash Dividend for non exceptional cases Calculation is INITIATED")
#                self.sql_cash_div_ex_excep["GTR(PAF)"]=(self.sql_cash_div_ex_excep["PriceExT1"] - ( self.sql_cash_div_ex_excep["EventAmount"] * self.sql_cash_div_ex_excep["FxExT1"]))/self.sql_cash_div_ex_excep["PriceExT1"]
                EventAmount=self.fn_cash_ex_excep("Cash Dividend","EventAmount")
                logA.debug("NTR_EventAmount_{0}".format(EventAmount))
                PriceExT1=self.fn_cash_ex_excep("Cash Dividend","PriceExT1")
                logA.debug("NTR_PriceExT1_{0}".format(PriceExT1))
                FxExT1=self.fn_cash_ex_excep("Cash Dividend","FxExT1")
                logA.debug("NTR_FxExT1_{0}".format(FxExT1))
                TaxRate=self.fn_cash_ex_excep("Cash Dividend","TaxRate")
                logA.debug("NTR_TaxRate_{0}".format(TaxRate))
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Div_NTR_PAF"]=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                logA.info("Div-CD-NTR Calculation is SUCCESFULLY done")
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Div_GTR_PAF"]=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                logA.info("Div-CD-GTR Calculation is SUCCESFULLY done")
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Div_PR_PAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Div_NSAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"SCR_GTR_UAF"]=( PriceExT1 / ( PriceExT1 - EventAmount * FxExT1))
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"SCR_NTR_UAF"]=( PriceExT1 / ( PriceExT1- EventAmount * FxExT1 * (TaxRate/100) ))
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"SCR_PR_UAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"SCR_PAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"AddC_GTR_CASH"]=EventAmount*FxExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"AddC_NTR_CASH"]=EventAmount*FxExT1*(TaxRate/100)
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"AddC_PR"]=1
                logA.info("Div-CD-PR Calculation is SUCCESFULLY done")
                logA.info("Second Cash Dividend Calculation is SUCCESFULLY done")
                self.sql_cash_div_ex_excep.to_csv("sql_cash_div_ex_excep.csv")
            else:
                logA.info("Second Cash Dividend for non-exceptional cases Calculation: NO RECORDS FOUND")
        except Exception as e:
            logA.error(e)
            logA.error("Second Cash Dividend for non exceptional cases Calculation has FAILED")
        try:
            if self.nd_final_combinedPay.loc[self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]),"EventType"].count() > 0:
                logA.info("Third Cash Dividend for pay date exceptional cases has INITIATED")
                k_PriceExT1=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"PayDatePriceT1"]
                k_Fx_1=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"PayDateFxT1"]
                k_TaxRate=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"TaxRate"]
                k_EventAmount=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"EventAmount"]
                #calculate PR,NTR,GTR
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Div_PR_PAF"]=1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Div_NTR_PAF"]=(k_PriceExT1 - (k_EventAmount*(k_TaxRate/100)*k_Fx_1))/k_PriceExT1                 
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Div_GTR_PAF"]=(k_PriceExT1 - (k_EventAmount*k_Fx_1))/k_PriceExT1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Div_NSAF"]=1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"SCR_GTR_UAF"]=k_PriceExT1/(k_PriceExT1 - (k_EventAmount*k_Fx_1))
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"SCR_NTR_UAF"]=k_PriceExT1/(k_PriceExT1 - (k_EventAmount*(k_TaxRate/100)*k_Fx_1))
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"SCR_PR_UAF"]=1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"SCR_PAF"]=1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"AddC_GTR_CASH"]=k_EventAmount*k_Fx_1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"AddC_NTR_CASH"]=k_EventAmount*k_Fx_1*(k_TaxRate/100)
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"AddC_PR_CASH"]=0
                self.nd_final_combinedPay.to_csv("nd_f_combinedpay.csv")
                logA.info("Third Cash Dividend for pay date exceptional calculation is SUCCESFULLY done")
            else:
                logA.info("Third Cash Dividend for pay date exceptional cases calculation: NO RECORDS FOUND")
        except Exception as e:
            logA.error(e)
            logA.error("Third Cash Dividend on Paydate handling has FAILED")
            
    def special_cash_dividend(self):
        """Calculation for special cash Dividend and similar kind of treatment"""
        try:
            """First Handling for non exceptional cases
               Second Handling for exceptional cases
               Third Handling for pay date exceptional cases"""
            #Exceptional cases will be handled the same as below
            logA.info("Special Cash Dividend for non exceptional cases Calculation is INITIATED")
            if (not self.sql_cash_div_ex_excep.empty) and (self.sql_cash_div_ex_excep.loc[(self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"])),"EventType"].count()>0):
                logA.info("Inside Special Cash Dividend treatment for non exceptional")
                s_EventAmount=self.fn_s_cash_ex_excep("Special Cash Dividend","EventAmount")
                s_PriceExT1=self.fn_s_cash_ex_excep("Special Cash Dividend","PriceExT1")
                s_FxExT1=self.fn_s_cash_ex_excep("Special Cash Dividend","FxExT1")
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Div_GTR_PAF"]=(s_PriceExT1 - ( s_EventAmount *s_FxExT1 )) / s_PriceExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Div_NTR_PAF"]=(s_PriceExT1 - ( s_EventAmount *s_FxExT1 )) / s_PriceExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Div_PR_PAF"]=(s_PriceExT1 -( s_EventAmount * s_FxExT1)) / s_PriceExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Div_NSAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"SCR_GTR_UAF"]=(s_PriceExT1)/(s_EventAmount * s_FxExT1)
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"SCR_NTR_UAF"]=(s_PriceExT1)/(s_EventAmount * s_FxExT1)
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"SCR_PR_UAF"]=(s_PriceExT1)/(s_EventAmount * s_FxExT1)
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"SCR_PAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"AddC_GTR_CASH"]=s_EventAmount*s_FxExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"AddC_NTR_CASH"]=s_EventAmount*s_FxExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"AddC_PR_CASH"]=0
                logA.debug("Total No of special cash dividend(non exceptional cases): {0}".format(s_PriceExT1.count()))
                logA.debug("PriceExT1_{0}".format(s_PriceExT1))
                logA.debug("FxExT1_{0}".format(s_FxExT1))
                logA.debug("DividendAmount_{0}".format(s_EventAmount))
                self.sql_cash_div_ex_excep.to_csv("Excluding_exception.csv")
#                self.sql_cash_div_ex_excep.loc[~self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"PR"]=(PriceExT1 -( DividendAmount * FxExT1))/PriceExT1
                logA.info("Special Cash Dividend for non exceptional cases Calculation is SUCCESFULLY done")
            else:
                logA.info("Special Cash Dividend for non exceptional cases : NO RECORDS FOUND")
                pass
            #handling depends 
            if (not self.sql_cash_div_except.empty) and (self.sql_cash_div_except.loc[self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"]),"EventType"].count() > 0):
                logA.info("Inside Special Cash Dividend treatment for Exceptional cases")
                au_eventAmount=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"EventAmount"]
                au_PriceExT1=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                au_Fx_1=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"FxExT1"]
                logA.debug("au_eventAmount= {}".format(au_eventAmount))
                logA.debug("au_PriceExT1= {}".format(au_PriceExT1))
                logA.debug("au_Fx_1= {}".format(au_Fx_1))
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Div_GTR_PAF"]=(au_PriceExT1-(au_eventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Div_NTR_PAF"]=(au_PriceExT1-(au_eventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Div_PR_PAF"]=(au_PriceExT1-(au_eventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Div_NSAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"SCR_GTR_UAF"]=(au_PriceExT1)/(au_eventAmount*au_Fx_1)
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"SCR_NTR_UAF"]=(au_PriceExT1)/(au_eventAmount*au_Fx_1)
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"SCR_PR_UAF"]=(au_PriceExT1)/(au_eventAmount*au_Fx_1)
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"SCR_PAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"AddC_GTR_CASH"]=au_eventAmount*au_Fx_1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"AddC_NTR_CASH"]=au_eventAmount*au_Fx_1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"AddC_PR_CASH"]=0
                self.sql_cash_div_except.to_csv("exceptional.csv")
            else:
                logA.info("Special Cash Dividend for exceptional cases : NO RECORDS FOUND")
                pass                         
            if (not self.nd_final_combinedPay.empty) and (self.nd_final_combinedPay.loc[(self.nd_final_combinedPay['LocalCurrency'].isin(["JP","KR"])) &(self.nd_final_combinedPay['EventType'].isin(['Special Cash Dividend'])),"EventType"].count() > 0):
                logA.info("Inside Special Cash Dividend treatment for Pay Date")
                jp_kr_PriceExT1=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])),"PayDatePriceT1"]
                jp_kr_eventAmount=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])),"EventAmount"]
                jp_kr_fx_1=au_Fx_1=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])),"PayDateFxT1"]
                logA.debug("jp_kr_PriceExT1= {}".format(jp_kr_PriceExT1))
                logA.debug("jp_kr_eventAmount= {}".format(jp_kr_eventAmount))
                logA.debug("jp_kr_fx_1= {}".format(jp_kr_fx_1))
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Div_GTR_PAF"]=(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))/jp_kr_PriceExT1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Div_NTR_PAF"]=(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))/jp_kr_PriceExT1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Div_PR_PAF"]=(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))/jp_kr_PriceExT1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Div_NSAF"]=1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"SCR_GTR_UAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"SCR_NTR_UAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"SCR_PR_UAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"SCR_PAF"]=1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"AddC_GTR_CASH"]=jp_kr_eventAmount*jp_kr_fx_1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"AddC_NTR_CASH"]=jp_kr_eventAmount*jp_kr_fx_1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"AddC_PR_CASH"]=0
                self.nd_final_combinedPay.to_csv("Combined.csv")
            else:
                logA.info("Special Cash Dividend for exceptional cases : NO RECORDS FOUND")
                pass 
                
        except Exception as e:
            logA.error(e)
            logA.error("Special Cash Dividend Calculation has FAILED")
            pass
    def stock_dividend(self):
        try:
            logA.info("Stock Dividend Calculation is INITIATED")
            new_shares=self.sql_others.loc[self.sql_data["EventType"].isin(["Stock Dividend"]),"TermNewShares"]
            old_shares=self.sql_others.loc[self.sql_data["EventType"].isin(["Stock Dividend"]),"TermOldShares"]
            m=new_shares/old_shares
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Dividend"]),"m"]=new_shares/old_shares
            self.sql_others.loc[self.sql_others["EventType"].isin(['Stock Dividend']),"Div_PAF"]=1/(1+m)
            self.sql_others.loc[self.sql_others["EventType"].isin(['Stock Dividend']),"Div_NSAF"]=1+m
            self.sql_others.loc[self.sql_others["EventType"].isin(['Stock Dividend']),"SCR_UAF"]=1+m
#            self.sql_others.to_csv("others.csv")
            logA.info("Stock Dividend Calculation has SUCCESSFULLY Completed")
        except Exception as e:
            logA.error(e)
            logA.error("Stock Dividend Calculation has FAILED")
            pass
    def stock_split(self):
        try:
            logA.info("Stock Dividend Calculation is INITIATED")
            new_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"TermNewShares"]
            old_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"TermOldShares"]
            m=new_shares/old_shares
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"Div_PAF"]=1/m
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"Div_NSAF"]=m
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"SCR_UAF"]=m          
            self.sql_others.to_csv("others.csv")
        except Exception as e:
            logA.error(e)
            logA.error("Special Cash Dividend Calculation has FAILED")
            pass
    def rights_issue(self):
        try:
            logA.info("Rights Issue Calculation is INITIATED")
            subs_price=self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"OfferPrice"]
            price_ex_1=self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"PriceExT1"]
            new_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"TermNewShares"]
            print("new_shares",new_shares)
            old_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"TermOldShares"]
            print("old_shares",old_shares)
            m=new_shares/old_shares
            print("Rights_issue",m)
            
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"m"]=m
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"Div_PAF"]=(price_ex_1-(m*subs_price))/price_ex_1
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"Div_NSAF"]=1-m
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"SCR_UAF"]=(price_ex_1*(1+m))/(price_ex_1+subs_price*m)
            self.sql_others.to_csv("f_sql_others.csv")
        except Exception as e:
            logA.error(e)
            logA.error("Rights Issue Calculation has FAILED")
            pass
    def buy_back(self):
        try:
            logA.info("Rights Issue Calculation is INITIATED")
            buybk_price=self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"OfferPrice"]
            price_ex_1=self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"PriceExT1"]
            new_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"TermNewShares"]
            old_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"TermOldShares"]
            m=new_shares/old_shares
            self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"PAF"]=(price_ex_1-(m*buybk_price))/price_ex_1
            self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"NSAF"]=1-m
            
        except Exception as e:
            logA.error(e)
            logA.error("Rights Issue Calculation has FAILED")
            pass
    def spin_off(self):
        try:
            logA.info("Spin off Calculation is INITIATED")
#            for events in list(set(self.sql_others["EventType"])):
#                if events=="Spin-off":
            PriceExT1=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"PriceExT1"]
            cash=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"SpunOffCash"]
            spun_entity_openprices=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"OfferPrice"]
            newshares=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"TermNewShares"]
            oldshares=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"TermOldShares"]
            m=newshares/oldshares
            self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"Div_PAF"]=(PriceExT1-cash-m*spun_entity_openprices)/PriceExT1
            self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"Div_NSAF"]=1
            self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"SCR_UAF"]=1
        except Exception as e:
            logA.error(e)
            logA.error("Spin off Calculation has FAILED")
if __name__=="__main__":
    check=rule_divisor()
    check.multi_CA_handler()
#    check.cash_dividend()
#    check.special_cash_dividend()
#    check.stock_dividend()
#    check.stock_split()
#    check.rights_issue()
