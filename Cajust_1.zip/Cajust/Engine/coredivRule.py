# -*- coding: utf-8 -*-
"""
Created on Tue Jul 16 11:33:08 2019

@author: tanmay.sidhu
"""

# -*- coding: utf-8 -*-
"""
Created on Mon May 13 10:36:20 2019

@author: tanmay.sidhu
"""
import pylogger
logA=pylogger.loggy()
from core_var import conf
import pandas as pd
#import numpy as np
class rule_divisor(conf):
    """This is for Divisor based Methodlogy"""

    def __init__(self):
        "Initialising all the variables used in this Divisor class"
        try:
            super().__init__()
            print("Inside rule divisor init")
            logA.info("Divisor is INITIATED")
            logA.info("Divisor Initiation is SUCCESFULLY done")
        except:
            logA.error("Divisor Initialisation has FAILED")
#    def fn_master(self,df,col1,col1_event,col2,col2_event):
#        self.df.loc[(self.df[col1].isin([i for i in col1_event]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"PriceExT1"]
        
    def fn_cash_ex_excep(self,event_type,eventvalue):
        """Just a func to have a clean code Structure"""
        return self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin([event_type]),eventvalue]

    def fn_s_cash_ex_excep(self,event_type,eventvalue):
         """Just a func to have a clean code Structure"""
         return self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin([event_type]),eventvalue]
    def fn_s_cash_excep(self,event_type,eventvalue):
         return self.sql_cash_div_except.loc[self.sql_cash_div_except["EventType"].isin([event_type]),eventvalue]
    def fn_handling_multiple(self,df1):
        final_pay=pd.DataFrame()
        final_ex=pd.DataFrame()
        print(">>>>>>>>>>>>>>>>>>",df1)
        
        """Handling sequence """
        #cash Dividend
        #Stock Dividend
        #stock Split
        #rights issue
        #spin off
        if df1=="pay":
            counter=0
            """Only Cash and  Dividend"""
            df_pay=self.d_final_combinedPay.groupby("CombinedPay")
            for i in list(df_pay.groups):
                grp_name=i
                i=df_pay.get_group(i)
                print("grp_name_pay",grp_name)
                if len(i.loc[i["EventType"].isin(["Cash Dividend"])])>0:
                    counter=counter+1
                    if i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"]).isin(["JP","KR"]),"EventType"].count() > 0:
                        jp_kr_PriceExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PayDatePriceT1"].values[0]
                        jp_kr_FxExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PayDateFxT1"].values[0]
                        jp_kr_TaxRate=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"TaxRate"].values[0]
                        jp_kr_event_amount=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"EventAmount"].sum()
#                        print("dem",(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1)
                        Div_GTR_PAF= (jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1                       
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_GTR_PAF"]=Div_GTR_PAF
                        Div_NTR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1)*(jp_kr_TaxRate/100))/jp_kr_PriceExT1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_NTR_PAF"]=Div_NTR_PAF
                        Div_PR_PAF=1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_PR_PAF"]=Div_PR_PAF
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_NSAF"]=1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"GTR_PriceExT1"]=jp_kr_PriceExT1*Div_GTR_PAF
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NTR_PriceExT1"]=jp_kr_PriceExT1*Div_NTR_PAF
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PR_PriceExT1"]=jp_kr_PriceExT1*Div_PR_PAF
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Counter"]=counter
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_GTR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_event_amount*jp_kr_FxExT1))
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_NTR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_event_amount*jp_kr_FxExT1*jp_kr_TaxRate/100))
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_PR_NSAF"]=1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_GTR_CASH"]=jp_kr_event_amount*jp_kr_FxExT1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_NTR_CASH"]=jp_kr_event_amount*jp_kr_FxExT1*jp_kr_TaxRate/100
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_PR_CASH"]=1
#                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_event_amount*jp_kr_FxExT1))
#                        i.to_csv("payCDtest.csv")
                if i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"]).isin(["JP","KR"]),"EventType"].count() > 0:
                    if max(i["Counter"])==0:
                        counter=counter+1
                        jp_kr_PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PayDatePriceT1"].values[0]
                        jp_kr_FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PayDateFxT1"].values[0]
                        jp_kr_TaxRate=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"TaxRate"].values[0]
                        jp_kr_event_amount=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"EventAmount"].sum()
                        Div_GTR_PAF=(jp_kr_PriceExT1-((jp_kr_event_amount)*(jp_kr_FxExT1)))/jp_kr_PriceExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_GTR_PAF"]=Div_GTR_PAF
                        Div_NTR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_NTR_PAF"]=Div_NTR_PAF
                        Div_PR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_PR_PAF"]=Div_PR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_NSAF"]=1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_GTR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-jp_kr_event_amount*jp_kr_FxExT1)
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_NTR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-jp_kr_event_amount*jp_kr_FxExT1)
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_PR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-jp_kr_event_amount*jp_kr_FxExT1)
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"GTR_PriceExT1"]=jp_kr_PriceExT1*Div_GTR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NTR_PriceExT1"]=jp_kr_PriceExT1*Div_NTR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PR_PriceExT1"]=jp_kr_PriceExT1*Div_PR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Counter"]=counter
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_GTR_CASH"]=jp_kr_event_amount*jp_kr_FxExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_NTR_CASH"]=jp_kr_event_amount*jp_kr_FxExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_PR_CASH"]=jp_kr_event_amount*jp_kr_FxExT1
                    else:
                        counter=counter+1
                        jp_kr_PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PayDatePriceT1"].values[0]
                        jp_kr_FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PayDateFxT1"].values[0]
                        jp_kr_TaxRate=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"TaxRate"].values[0]
                        jp_kr_event_amount=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"EventAmount"].sum()
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                        PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
                        Div_GTR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1
                        Div_NTR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1
                        Div_PR_PAF=(jp_kr_PriceExT1-(jp_kr_event_amount)*(jp_kr_FxExT1))/jp_kr_PriceExT1
                        print("Div_GTR_PAF",Div_GTR_PAF)
                        print("Div_NTR_PAF",Div_NTR_PAF)
                        print("Div_PR_PAF",Div_PR_PAF)
                        adj_div_GTR_PAF=GTR_PriceExT1*Div_GTR_PAF
                        adj_div_NTR_PAF=NTR_PriceExT1*Div_NTR_PAF
                        adj_div_PR_PAF=PR_PriceExT1*Div_PR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"GTR_PriceExT1"]=adj_div_GTR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"NTR_PriceExT1"]=adj_div_NTR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"PR_PriceExT1"]=adj_div_PR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_GTR_PAF"]=Div_GTR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_NTR_PAF"]=Div_NTR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Div_PR_PAF"]=Div_PR_PAF
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"Counter"]=counter
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_GTR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-jp_kr_event_amount*jp_kr_FxExT1)
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_NTR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-jp_kr_event_amount*jp_kr_FxExT1)
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"SCR_PR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-jp_kr_event_amount*jp_kr_FxExT1)
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_GTR_CASH"]=jp_kr_event_amount*jp_kr_FxExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_NTR_CASH"]=jp_kr_event_amount*jp_kr_FxExT1
                        i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["JP","KR"])),"AddC_PR_CASH"]=jp_kr_event_amount*jp_kr_FxExT1
                closeprice=i.loc[i["Counter"]==max(i["Counter"]),"PayDatePriceT1"].values[0]
                adj_GTR_price=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                adj_NTR_price=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                adj_PR_price=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
#                df = pd.DataFrame(columns=["CAInputID","Div_GTR_PAF","Div_NTR_PAF","Div_PR_PAF","Div_NSAF","SCR_GTR_NSAF","SCR_NTR_NSAF","SCR_PR_NSAF","SCR_PAF","AddC_GTR_CASH","AddC_NTR_CASH","AddC_PR_CASH"]))
                df = pd.DataFrame(columns=["CAInputID","Div_GTR_PAF","Div_NTR_PAF","Div_PR_PAF","Div_NSAF","SCR_GTR_NSAF","SCR_NTR_NSAF","SCR_PR_NSAF","SCR_PAF","AddC_GTR_CASH","AddC_NTR_CASH","AddC_PR_CASH"])
                if closeprice==adj_GTR_price:
                    print("final_1")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_GTR_PAF"] = 1
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_GTR_NSAF"]=i["SCR_GTR_NSAF"].prod()
                    df.loc[grp_name,"AddC_GTR_CASH"]=i["AddC_GTR_CASH"].sum()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1
                else:
                    print("final_2")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_GTR_PAF"]=adj_GTR_price/closeprice
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_GTR_NSAF"]=i["SCR_GTR_NSAF"].prod()
                    df.loc[grp_name,"AddC_GTR_CASH"]=i["AddC_GTR_CASH"].sum()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1
        
                if closeprice==adj_NTR_price:
                    print("final_3")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_NTR_PAF"]=1
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_NTR_NSAF"]=i["SCR_NTR_NSAF"].prod()
                    df.loc[grp_name,"AddC_NTR_CASH"]=i["AddC_NTR_CASH"].sum()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1
                else:
                    print("final_4")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_NTR_PAF"]=adj_NTR_price/closeprice
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_NTR_NSAF"]=i["SCR_NTR_NSAF"].prod()
                    df.loc[grp_name,"AddC_NTR_CASH"]=i["AddC_NTR_CASH"].sum()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1
                if closeprice==adj_PR_price:
                    print("final_5")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_PR_PAF"]=1
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_PR_NSAF"]=i["SCR_PR_NSAF"].prod()
                    df.loc[grp_name,"AddC_PR_CASH"]=i["AddC_PR_CASH"].sum()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1
                else:
                    print("final_6")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_PR_PAF"]=adj_PR_price/closeprice
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_PR_NSAF"]=i["SCR_PR_NSAF"].prod()
                    df.loc[grp_name,"AddC_PR_CASH"]=i["AddC_PR_CASH"].sum()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1

                print("DF",df)
                final_pay=final_pay.append(df)
#                print("FINAL",final)
            final_pay["Handled_on_PayDate"]="Yes"
            final_pay["Multiple_Case"]="Yes"
            return final_pay
#            final_pay.to_csv("pay_df.csv") 
                        
                        
        if df1=="ex":
            df_ex=self.d_final_combinedEx.groupby('CombinedEx')
#            df_ex=pd.read_csv("test_multica.csv").groupby("CombinedEx")
            for i in list(df_ex.groups):
                counter=0
                grp_name=i
                print("grp_name",grp_name)
                i=df_ex.get_group(i)
                
                i["Counter"]=0
                if len(i.loc[i["EventType"].isin(['Cash Dividend'])]) > 0:
                    logA.info("Multiple CA : Cash Dividend status Initiated")
                    counter=counter+1
#                    print("Inside duplicates: Cash Dividend")
                    if i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"EventType"].count() > 0:
                        logA.info("Inside duplicates: Cash Dividend_AU")
                        i.loc[(i["EventType"].isin(['Cash Dividend']))&(i["LocalCurrency"].isin(["AU"])),"Counter"]=counter
                        au_PriceExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PriceExT1"].values[0]
                        au_Fx_1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"FxExT1"].values[0]
                        au_TaxRate=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"TaxRate"].values[0]
                        Frank_Percent=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"FrankingPercent"].values[0]
                        Income_dis_percent=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"IncomePercent"].values[0]
                        Ef_TaxRate=(au_TaxRate/100)*(1 - (Frank_Percent/100) - (Income_dis_percent/100))
                        au_EventAmount=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"EventAmount"].sum()
                        Ef_EventAmount=au_EventAmount*(1-Ef_TaxRate)
                        Div_GTR_PAF=(au_PriceExT1-(au_EventAmount*au_Fx_1))/au_PriceExT1
                        Div_NTR_PAF=(au_PriceExT1-(Ef_EventAmount*au_Fx_1))/au_PriceExT1 
                        i.loc[i["LocalCurrency"].isin(["AU"])&(i["EventType"].isin(["Cash Dividend"])),"Div_GTR_PAF"]=Div_GTR_PAF
                        i.loc[i["LocalCurrency"].isin(["AU"])&(i["EventType"].isin(["Cash Dividend"])),"Div_NTR_PAF"]=Div_NTR_PAF
                        i.loc[i["LocalCurrency"].isin(["AU"])&(i["EventType"].isin(["Cash Dividend"])),"Div_PR_PAF"]=1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_NSAF"]=1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_GTR_NSAF"]=au_PriceExT1/((au_PriceExT1-(au_EventAmount*au_Fx_1)))
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_NTR_NSAF"]=au_PriceExT1/((au_PriceExT1-(Ef_EventAmount*au_Fx_1)))
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_PR_NSAF"]=1
                        aus_adj_price_NTR=Div_NTR_PAF*au_PriceExT1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"NTR_PriceExT1"]=aus_adj_price_NTR
                        aus_adj_price_GTR=Div_GTR_PAF*au_PriceExT1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"GTR_PriceExT1"]=aus_adj_price_GTR
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PR_PriceExT1"]=au_PriceExT1*1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_GTR_CASH"]=au_EventAmount*au_Fx_1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_NTR_CASH"]=Ef_EventAmount*au_Fx_1
                        i.loc[(i["EventType"].isin(["Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_PR_CASH"]=1
#                        i.to_csv("case_1.csv")
                        logA.info("Multiple CA of Exceptional cases is SUCESSFULLY completed")
                    if len(i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU']))]) > 0:
                        logA.info("Multiple, Inside duplicates: cash dividend other than AU")
                        if max(i["Counter"])==0:
#                            print(grp_name,"Inside duplicates: cash dividend other than AU_1")
                            logA.info("Inside duplicates: cash dividend other than AU_1")
                            PriceExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"PriceExT1"].values[0]
                            EventAmount=i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i["LocalCurrency"].isin(['AU'])),"EventAmount"].sum()
                            FxExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"FxExT1"].values[0]
                            TaxRate=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"TaxRate"].values[0]
                            print("TaxRate",TaxRate)
                            Div_GTR_PAF=((PriceExT1 - ( EventAmount * FxExT1)) / PriceExT1)
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                            print("Div_NTR_PAF",Div_NTR_PAF)
                            Div_PR_PAF=1
                            
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NSAF"]=1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"SCR_GTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"SCR_NTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100)))
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"SCR_PR_NSAF"]=1
#                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"SCR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            GTR_PriceExT1=PriceExT1*Div_GTR_PAF
                            NTR_PriceExT1=PriceExT1*Div_NTR_PAF
                            PR_PriceExT1=PriceExT1*Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"GTR_PriceExT1"]=GTR_PriceExT1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"NTR_PriceExT1"]=NTR_PriceExT1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"PR_PriceExT1"]=PR_PriceExT1
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_GTR_CASH"]=EventAmount * FxExT1
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_NTR_CASH"]=EventAmount * FxExT1 * (TaxRate/100)
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_PR_CASH"]=1
#                            i.to_csv("testing_multi.csv")
                        else:
                            logA.info("Multiple, Inside duplicates: cash dividend other than AU_2")
                            print("Inside duplicates: cash dividend other than AU_2")
                            PriceExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                            EventAmount=i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i["LocalCurrency"].isin(['AU'])),"EventAmount"].sum()
                            GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].reset_index(drop=True)
                            NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].reset_index(drop=True)
                            PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].reset_index(drop=True)
                            FxExT1=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"FxExT1"]
                            TaxRate=i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"TaxRate"]
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                            Div_PR_PAF=1
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            adj_price_GTR=Div_GTR_PAF*GTR_PriceExT1
                            adj_price_NTR=Div_NTR_PAF*NTR_PriceExT1
                            adj_price_PR=Div_PR_PAF*PR_PriceExT1
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_GTR_NSAF"]=PriceExT1 /(PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_NTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) ))
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_PR_NSAF"]=1
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"GTR_PriceExT1"]=adj_price_GTR
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"NTR_PriceExT1"]=adj_price_NTR
                            i.loc[(i['EventType'].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"PR_PriceExT1"]=adj_price_PR
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_GTR_CASH"]=EventAmount * FxExT1
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_NTR_CASH"]=EventAmount * FxExT1 * (TaxRate/100)
                            i.loc[(i["EventType"].isin(['Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_PR_CASH"]=1
#                        i.to_csv("i.csv")

                if len(i.loc[(i['EventType'].isin(['Special Cash Dividend']))]) > 0:
                    print("Multiple, Inside duplicates: special cash")
                    if i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"EventType"].count() > 0:
                        if max(i["Counter"])==0:
                            print("yo")
                            counter=counter+1
                            print("Inside duplicates: special cash_AU_counter=0")
                            logA.info("Inside duplicates: special cash_AU")
#                            SA_PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                            PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                            EventAmount=i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(i["LocalCurrency"].isin(['AU'])),"EventAmount"].sum()
                            FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"FxExT1"]
                            TaxRate=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"TaxRate"]
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1)) / PriceExT1
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                            Div_PR_PAF=1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_NSAF"]=1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_GTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_NTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100)))
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_PR_NSAF"]=1
#                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"SCR_NSAF"]=1
                            GTR_PriceExT1=PriceExT1*Div_GTR_PAF
                            NTR_PriceExT1=PriceExT1*Div_NTR_PAF
                            PR_PriceExT1=PriceExT1*Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"GTR_PriceExT1"]=GTR_PriceExT1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"NTR_PriceExT1"]=NTR_PriceExT1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PR_PriceExT1"]=PR_PriceExT1
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_GTR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_NTR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_PR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                        else:
                            print("yo_1")
                            counter=counter+1
                            logA.info("Multiple, Special Cash Dividend ")
                            PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"PriceExT1"].values[0]
                            GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                            NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                            PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
                            FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"FxExT1"].values[0]
                            TaxRate=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"TaxRate"].values[0]
                            EventAmount=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"EventAmount"].sum()
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_PR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            adj_price_GTR=Div_GTR_PAF*GTR_PriceExT1
                            adj_price_NTR=Div_NTR_PAF*NTR_PriceExT1
                            adj_price_PR=Div_PR_PAF*PR_PriceExT1
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"GTR_PriceExT1"]=adj_price_GTR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"NTR_PriceExT1"]=adj_price_NTR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"PR_PriceExT1"]=adj_price_PR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"SCR_GTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"SCR_NTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"SCR_PR_NSAF"]=1
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_GTR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_NTR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(i["LocalCurrency"].isin(["AU"])),"AddC_PR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                    if i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"EventType"].count() > 0:
                        if max(i["Counter"])==0:
                            print("yo_2")
                            logA.info("Inside multi CA Special cash dividend other than AU and counter=0")
                            counter=counter+1
                            PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                            FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"FxExT1"]
                            EventAmount=i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i["LocalCurrency"].isin(['AU'])),"EventAmount"].sum()
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_PR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NSAF"]=1
                            adj_price_GTR=Div_GTR_PAF*PriceExT1
                            adj_price_NTR=Div_NTR_PAF*PriceExT1
                            adj_price_PR=Div_PR_PAF*PriceExT1
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"GTR_PriceExT1"]=adj_price_GTR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"NTR_PriceExT1"]=adj_price_NTR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"PR_PriceExT1"]=adj_price_PR
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_GTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_NTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_PR_NSAF"]=1
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_GTR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_NTR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_PR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
#                            i.to_csv("special.csv")
                        else:
                            logA.info("Inside multi CA Special cash dividend other than AU and counter!=0")
#                            print("a",type(max(i["Counter"])))
                            counter=counter+1
                            print("yo_3")
#                            GTR_PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"GTR_PriceExT1"].values[0]
                            PriceExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"PriceExT1"].values[0]
                            GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                            NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                            PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
                            FxExT1=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"FxExT1"].values[0]
#                            TaxRate=i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"TaxRate"]
                            EventAmount=i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i["LocalCurrency"].isin(['AU'])),"EventAmount"].sum()
                            Div_GTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_NTR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                            Div_PR_PAF=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1                            
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_GTR_PAF"]=Div_GTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NTR_PAF"]=Div_NTR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_PR_PAF"]=Div_PR_PAF
                            i.loc[(i["EventType"].isin(["Special Cash Dividend"]))&(~i["LocalCurrency"].isin(["AU"])),"Div_NSAF"]=1
                            adj_price_GTR=Div_GTR_PAF*GTR_PriceExT1
                            adj_price_NTR=Div_NTR_PAF*NTR_PriceExT1
                            adj_price_PR=Div_PR_PAF*PR_PriceExT1
                            print("adj_price_NTR",adj_price_NTR)
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"GTR_PriceExT1"]=adj_price_GTR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"NTR_PriceExT1"]=adj_price_NTR
                            i.loc[(i['EventType'].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"PR_PriceExT1"]=adj_price_PR
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"Counter"]=counter
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_GTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_NTR_NSAF"]=PriceExT1 / (PriceExT1 - ( EventAmount * FxExT1 ))
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"SCR_PR_NSAF"]=1
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_GTR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_NTR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
                            i.loc[(i["EventType"].isin(['Special Cash Dividend']))&(~i['LocalCurrency'].isin(['AU'])),"AddC_PR_CASH"]=PriceExT1 - ( EventAmount * FxExT1 )
#                            i.to_csv("test.csv")
                if len(i.loc[i["EventType"].isin(["Stock Dividend"])]) > 0:
                    if max(i["Counter"])!=0:
                        logA.info("Inside multi CA: Stock Dividend, counter!=0")
                        counter=counter+1
                        TermNewShares=i.loc[(i["EventType"].isin(["Stock Dividend"]),"TermNewShares")].values[0]
                        TermOldShares=i.loc[(i["EventType"].isin(["Stock Dividend"]),"TermOldShares")].values[0]
                        m=TermNewShares/TermOldShares
                        PAF=1/1+m
                        NSAF=1+m
#                        PAF.reset_index(drop=True,inplace=True)
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"Div_PAF"]=PAF
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"Div_NSAF"]=NSAF
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"SCR_NSAF"]=NSAF
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                        PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
                        adj_price_GTR=PAF*GTR_PriceExT1
                        adj_price_NTR=PAF*NTR_PriceExT1
                        adj_price_PR=PAF*PR_PriceExT1
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"GTR_PriceExT1"]=adj_price_GTR
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"NTR_PriceExT1"]=adj_price_NTR
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"PR_PriceExT1"]=adj_price_PR
#                        i.loc[i["EventType"].isin(["Stock Dividend"]),"Div_NSAF"]=1-m
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"Counter"]=counter
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"AddC_GTR_CASH"]=0
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"AddC_NTR_CASH"]=0
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"AddC_PR_CASH"]=0
                        
#                    i.loc[i["EventType"].isin(["Stock Dividend"],"Counter")]=counter
                    else:
                        counter=counter+1 
                        TermNewShares=i.loc[(i["EventType"].isin(["Stock Dividend"]),"TermNewShares")].values[0]
                        TermOldShares=i.loc[(i["EventType"].isin(["Stock Dividend"]),"TermOldShares")].values[0]
                        PriceExT1=i.loc[(i["EventType"].isin(["Stock Dividend"])),"PriceExT1"].values[0]
                        m=TermNewShares/TermOldShares
                        PAF=1/(1+m)
                        NSAF=1+m
#                        NSAF.reset_index(drop=True,inplace=True)
#                        PAF.reset_index(drop=True,inplace=True)
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"Div_PAF"]=PAF
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"Div_NSAF"]=NSAF
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"SCR_GTR_NSAF"]=NSAF
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"SCR_NTR_NSAF"]=NSAF
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"SCR_PR_NSAF"]=NSAF
                        adj_price_GTR=PAF*PriceExT1
                        adj_price_NTR=PAF*PriceExT1
                        adj_price_PR=PAF*PriceExT1
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"GTR_PriceExT1"]=adj_price_GTR
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"NTR_PriceExT1"]=adj_price_NTR
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"PR_PriceExT1"]=adj_price_PR
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"Counter"]=counter
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"AddC_GTR_CASH"]=0
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"AddC_NTR_CASH"]=0
                        i.loc[i["EventType"].isin(["Stock Dividend"]),"AddC_PR_CASH"]=0
                if len(i.loc[i["EventType"].isin(["Stock Split"])]) > 0:
                    counter=counter+1
#                    i.loc[i["EventType"].isin(["Stock Split"]),"Counter"]=counter
                    TermNewShares=i.loc[i["EventType"].isin(["Stock Split"]),"TermNewShares"].values[0]
                    TermOldShares=i.loc[i["EventType"].isin(["Stock Split"]),"TermOldShares"].values[0]
                    m=TermNewShares/TermOldShares
                    PAF=1/m
#                    PAF.reset_index(inplace=True,drop=True)
                    i.loc[i["EventType"].isin(["Stock Split"]),"Div_PAF"]=PAF
                    i.loc[i["EventType"].isin(["Stock Split"]),"Div_NSAF"]=m
                    i.loc[i["EventType"].isin(["Stock Split"]),"SCR_GTR_NSAF"]=m
                    i.loc[i["EventType"].isin(["Stock Split"]),"SCR_NTR_NSAF"]=m
                    i.loc[i["EventType"].isin(["Stock Split"]),"SCR_PR_NSAF"]=m
                    i.loc[i["EventType"].isin(["Stock Split"]),"AddC_GTR_CASH"]=0
                    i.loc[i["EventType"].isin(["Stock Split"]),"AddC_NTR_CASH"]=0
                    i.loc[i["EventType"].isin(["Stock Split"]),"AddC_PR_CASH"]=0
#                    i.loc[i["EventType"].isin(["Stock Split"]),"Add"]=m
#                    print(i["Counter"])
                    if max(i["Counter"]) != 0:
                        print("here",max(i["Counter"]))
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                        PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
                        adj_price_GTR=PAF*GTR_PriceExT1
                        adj_price_NTR=PAF*NTR_PriceExT1
                        adj_price_PR=PAF*PR_PriceExT1
                        print("adj_price_GTR",adj_price_GTR)
                        print("adj_price_NTR",adj_price_NTR)
                        print("adj_price_PR",adj_price_PR)
#                        print("shereadjpr",PR_PriceExT1)
                        i.loc[i["EventType"].isin(["Stock Split"]),"GTR_PriceExT1"]=adj_price_GTR
                        i.loc[i["EventType"].isin(["Stock Split"]),"NTR_PriceExT1"]=adj_price_NTR
                        i.loc[i["EventType"].isin(["Stock Split"]),"PR_PriceExT1"]=adj_price_PR
                    else:
                        counter=counter+1
                        PriceExT1=i.loc[i["EventType"].isin(["Stock Split"]),"PriceExT1"]
                        adj_price_GTR=PAF*PriceExT1
                        adj_price_NTR=PAF*PriceExT1
                        adj_price_PR=PAF*PriceExT1
                        i.loc[i["EventType"].isin(["Stock Split"]),"GTR_PriceExT1"]=adj_price_GTR
                        i.loc[i["EventType"].isin(["Stock Split"]),"NTR_PriceExT1"]=adj_price_NTR
                        i.loc[i["EventType"].isin(["Stock Split"]),"PR_PriceExT1"]=adj_price_PR
                        i.loc[i["EventType"].isin(["Stock Split"]),"Counter"]=counter
#                    i.to_csv("split.csv")
                    
                if len(i.loc[i["EventType"].isin(["Rights Issue"])]) > 0:
                    counter=counter+1
                    PriceExT1=i.loc[i["EventType"].isin(["Rights Issue"]),"PriceExT1"].values[0]
                    TermNewShares=i.loc[(i["EventType"].isin(["Rights Issue"]),"TermNewShares")].values[0]
                    TermoldShares=i.loc[(i["EventType"].isin(["Rights Issue"]),"TermOldShares")].values[0]
                    m=TermNewShares/TermoldShares
                    print("m",m)
                    offerprice=i.loc[(i["EventType"].isin(["Rights Issue"])),"OfferPrice"].values[0]
                    PAF=(PriceExT1+(m*offerprice))/PriceExT1*(1-m)
                    i.loc[i["EventType"].isin(["Rights Issue"]),"Div_NSAF"]=1+m
                    i.loc[i["EventType"].isin(["Rights Issue"]),"SCR_GTR_NSAF"]=PriceExT1*(1+m)/(PriceExT1+offerprice*m)
                    i.loc[i["EventType"].isin(["Rights Issue"]),"SCR_NTR_NSAF"]=PriceExT1*(1+m)/(PriceExT1+offerprice*m)
                    i.loc[i["EventType"].isin(["Rights Issue"]),"SCR_PR_NSAF"]=PriceExT1*(1+m)/(PriceExT1+offerprice*m)
                    i.loc[i["EventType"].isin(["Rights Issue"]),"AddC_GTR_CASH"]=0
                    i.loc[i["EventType"].isin(["Rights Issue"]),"AddC_NTR_CASH"]=0
                    i.loc[i["EventType"].isin(["Rights Issue"]),"AddC_PR_CASH"]=0
                    if max(i["Counter"])!=0:
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                        PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
                        adj_price_GTR=GTR_PriceExT1*PAF
                        adj_price_NTR=NTR_PriceExT1*PAF
                        adj_price_PR=PR_PriceExT1*PAF
                        print("adj_price_GTR",GTR_PriceExT1)
                        print("adj_price_NTR",NTR_PriceExT1)
                        print("adj_price_PR",PR_PriceExT1)
                        print("PAF",PAF)
                        i.loc[i["EventType"].isin(["Rights Issue"]),"GTR_PriceExT1"]=adj_price_GTR
                        i.loc[i["EventType"].isin(["Rights Issue"]),"NTR_PriceExT1"]=adj_price_NTR
                        i.loc[i["EventType"].isin(["Rights Issue"]),"PR_PriceExT1"]=adj_price_PR
                        i.loc[i["EventType"].isin(["Rights Issue"]),"Counter"]=counter
                    else:
                        PriceExT1=i.loc[i["EventType"].isin(["Rights Issue"]),"PriceExT1"].values[0]
                        TermNewShares=i.loc[(i["EventType"].isin(["Rights Issue"])),"TermNewShares"].values[0]
                        TermoldShares=i.loc[(i["EventType"].isin(["Rights Issue"])),"TermOldShares"].values[0]
                        m=TermNewShares/TermoldShares
                        offerprice=i.loc[(i["EventType"].isin(["Rights Issue"])),"OfferPrice"].values[0]
                        PAF=(PriceExT1+(m*offerprice))/PriceExT1*(1-m)
                        adj_price_GTR=GTR_PriceExT1*PAF
                        adj_price_NTR=NTR_PriceExT1*PAF
                        adj_price_PR=PR_PriceExT1*PAF
                        i.loc[i["EventType"].isin(["Rights Issue"]),"GTR_PriceExT1"]=adj_price_GTR
                        i.loc[i["EventType"].isin(["Rights Issue"]),"NTR_PriceExT1"]=adj_price_NTR
                        i.loc[i["EventType"].isin(["Rights Issue"]),"PR_PriceExT1"]=adj_price_PR
                        i.loc[i["EventType"].isin(["Rights Issue"]),"Counter"]=counter
                    """Need to include the NSAF"""
          
                if len(i.loc[i["EventType"].isin(["Spin off"])]) >0:
                    print("inside spin off case")
                    counter=counter+1
                    PriceExT1=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"PriceExT1"].values[0]
                    cash=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"SpunOffCash"].values[0]
                    spun_entity_openprices=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"OfferPrice"].values[0]
                    newshares=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"TermNewShares"].values[0]
                    oldshares=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"TermOldShares"].values[0]
                    m=newshares/oldshares
                    PAF_spin=(PriceExT1-cash-m*spun_entity_openprices)/PriceExT1
#                    PAF_spin.reset_index(inplace=True,drop=True)
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"Div_PAF"]=PAF_spin
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"Div_NSAF"]=1
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"SCR_NSAF"]=1
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"AddC_GTR_CASH"]=0
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"AddC_NTR_CASH"]=0
                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"AddC_PR_CASH"]=0
#                    self.sql_others.loc[self.sql_others["EventType"].isin(["Spin-off"]),"SCR_PAF"]=1
                    if max(i["Counter"])!=0:
                        GTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                        NTR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                        PR_PriceExT1=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
                        adj_price_GTR=PAF_spin*GTR_PriceExT1
                        adj_price_NTR=PAF_spin*NTR_PriceExT1
                        adj_price_PR=PAF_spin*PR_PriceExT1
                        i.loc[i["EventType"].isin(["Spin-off"]),"GTR_PriceExT1"]=adj_price_GTR
                        i.loc[i["EventType"].isin(["Spin-off"]),"NTR_PriceExT1"]=adj_price_NTR
                        i.loc[i["EventType"].isin(["Spin-off"]),"PR_PriceExT1"]=adj_price_PR
                        i.loc[i["EventType"].isin(["Spin-off"]),"Counter"]=counter
                    else:
                        adj_price_GTR=PAF_spin*PriceExT1
                        adj_price_NTR=PAF_spin*PriceExT1
                        adj_price_PR=PAF_spin*PriceExT1
                        i.loc[i["EventType"].isin(["Spin-off"]),"GTR_PriceExT1"]=adj_price_GTR
                        i.loc[i["EventType"].isin(["Spin-off"]),"NTR_PriceExT1"]=adj_price_NTR
                        i.loc[i["EventType"].isin(["Spin-off"]),"PR_PriceExT1"]=adj_price_PR
                        i.loc[i["EventType"].isin(["Spin-off"]),"Counter"]=counter
                        
                closeprice=i.loc[i["Counter"]==max(i["Counter"]),"PriceExT1"].values[0]
                adj_GTR_price=i.loc[i["Counter"]==max(i["Counter"]),"GTR_PriceExT1"].values[0]
                adj_NTR_price=i.loc[i["Counter"]==max(i["Counter"]),"NTR_PriceExT1"].values[0]
                adj_PR_price=i.loc[i["Counter"]==max(i["Counter"]),"PR_PriceExT1"].values[0]
                df = pd.DataFrame(columns=["CAInputID","Div_GTR_PAF","Div_NTR_PAF","Div_PR_PAF","Div_NSAF","SCR_GTR_NSAF","SCR_NTR_NSAF","SCR_PR_NSAF","SCR_PAF","AddC_GTR_CASH","AddC_NTR_CASH","AddC_PR_CASH"])
                if closeprice==adj_GTR_price:
                    print("final_1")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_GTR_PAF"] = 1
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_GTR_NSAF"]=i["SCR_GTR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1
                    df.loc[grp_name,"AddC_GTR_CASH"]=i["AddC_GTR_CASH"].sum()
                else:
                    print("final_2")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_GTR_PAF"]=adj_GTR_price/closeprice
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_GTR_NSAF"]=i["SCR_GTR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1
#                    print(i["AddC_GTR_CASH"].sum())
                    df.loc[grp_name,"AddC_GTR_CASH"]=i["AddC_GTR_CASH"].sum()
#                    df.to_csv("final_2.csv")
        
                if closeprice==adj_NTR_price:
                    print("final_3")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_NTR_PAF"]=1
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_NTR_NSAF"]=i["SCR_NTR_NSAF"].prod()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PAF"]=1
                    df.loc[grp_name,"AddC_NTR_CASH"]=i["AddC_NTR_CASH"].sum()
                else:
                    print("final_4")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_NTR_PAF"]=adj_NTR_price/closeprice
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_NTR_NSAF"]=i["SCR_NTR_NSAF"].prod()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"AddC_NTR_CASH"]=i["AddC_NTR_CASH"].sum()
                    df.loc[grp_name,"SCR_PAF"]=1
                if closeprice==adj_PR_price:
                    print("final_5")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_PR_PAF"]=1
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
#                    df.loc[grp_name,"SCR_NSAF"]=i["SCR_NSAF"].prod()
                    df.loc[grp_name,"SCR_PR_NSAF"]=i["SCR_PR_NSAF"].prod()
                    df.loc[grp_name,"AddC_PR_CASH"]=i["AddC_PR_CASH"].sum()
                    df.loc[grp_name,"SCR_PAF"]=1
                else:
                    print("final_6")
                    df.loc[grp_name,"CAInputID"]=i["CAInputID"].values[0]
                    df.loc[grp_name,"Div_PR_PAF"]=adj_PR_price/closeprice
                    df.loc[grp_name,"Div_NSAF"]=i["Div_NSAF"].prod()
                    df.loc[grp_name,"SCR_PR_NSAF"]=i["SCR_PR_NSAF"].prod()
                    df.loc[grp_name,"AddC_PR_CASH"]=i["AddC_PR_CASH"].sum()
                    df.loc[grp_name,"SCR_PAF"]=1

#                print("DF",df)
#                df.to_csv("multi_ca.csv")
                final_ex=final_ex.append(df)
#                print("FINAL",final)
            final_ex["Handled_on_PayDate"]="No"
            final_ex["Multiple_Case"]="Yes"
            return final_ex
#            final_ex.to_csv("final_ex.csv")               
   
    def multi_CA_handler(self):
        if (self.d_final_combinedEx is not None) or (not self.d_final_combinedEx.empty):
            print("Dupli",1)
            ex_df=self.fn_handling_multiple("ex")
        if (self.d_final_combinedPay is not None) or (not self.d_final_combinedPay.empty):
            print("Dupli",2)
            pay_df=self.fn_handling_multiple("pay")
        if ((ex_df is not None) or (not ex_df.empty)) and ((pay_df is not None) or (not pay_df.empty)):
            final_frame=ex_df.append(pay_df)
            final_frame.reset_index(inplace=True)
            final_frame[["IdentifierMappingId","ExDate"]]=pd.DataFrame(final_frame["index"].str.split("_").to_list(),columns=["IdentifierMappingID","ExDate"])
            final_frame=final_frame[["CAInputID","ExDate","IdentifierMappingId","Div_GTR_PAF", "Div_NTR_PAF", "Div_PR_PAF", "Div_NSAF", "SCR_GTR_NSAF","SCR_NTR_NSAF","SCR_PR_NSAF","AddC_GTR_CASH","AddC_NTR_CASH","AddC_PR_CASH" ,"Handled_on_PayDate" , "Multiple_Case"]]
            final_frame.to_csv("final_frame.csv")
            return final_frame
        elif (pay_df is None) or (pay_df.empty):
            return ex_df
        elif (ex_df is None) or (ex_df.empty):
            return pay_df
            
            
        
    def cash_dividend(self):
        """Calculation of PAF for Cash Dividend"""
        try:#CHANGE Country CODE to currency HERE"""
            """First Handling cash dividend for exceptional cases
                Second Handling cash dividend for non exceptional cases
                Third Handling cash dividend for pay date exceptional cases """
        #Handling of AuSCRalian stock security
            if self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"EventType"].count() > 0:
#                print("testing",self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"]))].count())
                logA.info("Non multiple First Cash Dividend for exceptional cases Calculation is INITIATED")
                """CHANGE Country CODE to currency HERE"""
                au_PriceExT1=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                logA.info("Inside Cash divi_AU {}".format(au_PriceExT1))
                au_Fx_1=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"FxExT1"]
                logA.debug("Value of Au_FX_1= {} ".format(au_Fx_1))
                au_TaxRate=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"TaxRate"]
                logA.debug("Value of au_TaxRate= {} ".format(au_TaxRate))
                Frank_Percent=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"FrankingPercent"]
                logA.debug("Value of Frank_Percent= {} ".format(Frank_Percent))
                Income_dis_percent=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"IncomePercent"]
                logA.debug("Value of Income_dis_percent= {} ".format(Income_dis_percent))
                Ef_TaxRate=(au_TaxRate/100)*(1 - Frank_Percent - Income_dis_percent)
                logA.debug("Value of Ef_TaxRate= {} ".format(Ef_TaxRate))
                au_EventAmount=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"EventAmount"]
                logA.debug("Value of au_EventAmount= {} ".format(au_EventAmount))
#                self.sql_cash_div_except.to_csv("AU_check.csv")
                Ef_EventAmount=au_EventAmount*(1-Ef_TaxRate)
                logA.debug("Value of Ef_EventAmount= {} ".format(Ef_EventAmount))
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Div_GTR_PAF"]=(au_PriceExT1-(au_EventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Div_NTR_PAF"]=(au_PriceExT1-(Ef_EventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Div_PR_PAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Div_NSAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"SCR_GTR_NSAF"]=(au_PriceExT1)/(au_PriceExT1-(au_EventAmount*au_Fx_1))
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"SCR_NTR_NSAF"]=(au_PriceExT1)/(au_PriceExT1-(Ef_EventAmount*au_Fx_1))
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"SCR_PR_NSAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"SCR_PAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"AddC_GTR_CASH"]=au_EventAmount*au_Fx_1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"AddC_NTR_CASH"]=Ef_EventAmount*au_Fx_1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"AddC_PR_CASH"]=0
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Handled_on_PayDate"]="No"
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Cash Dividend"])),"Multiple_Case"]="No"
#                self.sql_cash_div_except .to_csv("sql_cash_div_except_1.csv")
                logA.info("Non Multiple First Cash Dividend for exceptional cases Calculation status: SUCCESS")
            else:
                logA.info("Non Multiple First Cash Dividend for exceptional cases Calculation: NO RECORDS FOUND")
        except Exception as e:
            logA.error(e)
            logA.error("First Cash Dividend for exceptional cases Calculation has FAILED")
        try:
            if self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"EventType"].count() > 0:
                logA.info("Second Cash Dividend for non exceptional cases Calculation is INITIATED")
#                self.sql_cash_div_ex_excep["GTR(PAF)"]=(self.sql_cash_div_ex_excep["PriceExT1"] - ( self.sql_cash_div_ex_excep["EventAmount"] * self.sql_cash_div_ex_excep["FxExT1"]))/self.sql_cash_div_ex_excep["PriceExT1"]
                EventAmount=self.fn_cash_ex_excep("Cash Dividend","EventAmount")
                logA.debug("NTR_EventAmount_{0}".format(EventAmount))
                PriceExT1=self.fn_cash_ex_excep("Cash Dividend","PriceExT1")
                logA.debug("NTR_PriceExT1_{0}".format(PriceExT1))
                FxExT1=self.fn_cash_ex_excep("Cash Dividend","FxExT1")
                logA.debug("NTR_FxExT1_{0}".format(FxExT1))
                TaxRate=self.fn_cash_ex_excep("Cash Dividend","TaxRate")
                logA.debug("NTR_TaxRate_{0}".format(TaxRate))
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Div_NTR_PAF"]=(PriceExT1 - ( EventAmount * FxExT1 * (TaxRate/100) )) / PriceExT1
                logA.info("Div-CD-NTR Calculation is SUCCESFULLY done")
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Div_GTR_PAF"]=(PriceExT1 - ( EventAmount * FxExT1 )) / PriceExT1
                logA.info("Div-CD-GTR Calculation is SUCCESFULLY done")
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Div_PR_PAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Div_NSAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"SCR_GTR_NSAF"]=( PriceExT1 / ( PriceExT1 - EventAmount * FxExT1))
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"SCR_NTR_NSAF"]=( PriceExT1 / ( PriceExT1- EventAmount * FxExT1 * (TaxRate/100) ))
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"SCR_PR_NSAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"SCR_PAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"AddC_GTR_CASH"]=EventAmount*FxExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"AddC_NTR_CASH"]=EventAmount*FxExT1*(TaxRate/100)
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"AddC_PR_CASH"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Handled_on_PayDate"]="No"
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Cash Dividend"]),"Multiple_Case"]="No"
#                self.sql_cash_div_ex_excep.to_csv("sql_cash_div_ex_excep_1.csv")
                logA.info("Div-CD-PR Calculation is SUCCESFULLY done")
                logA.info("Non multiple Second Cash Dividend Calculation status: SUCCESS")
#                self.sql_cash_div_ex_excep.to_csv("ex_cd_exceptional_2.csv")
            else:
                logA.info("Second Cash Dividend for non-exceptional cases Calculation: NO RECORDS FOUND")
        except Exception as e:
            logA.error(e)
            logA.error("Non multiple Second Cash Dividend for non exceptional cases Calculation status: FAILED")
        try:
            if self.nd_final_combinedPay.loc[self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]),"EventType"].count() > 0:
                logA.info("Non Multiple Third Cash Dividend for pay date cases has INITIATED")
                k_PriceExT1=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"PayDatePriceT1"]
                k_Fx_1=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"PayDateFxT1"]
                k_TaxRate=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"TaxRate"]
                k_EventAmount=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"EventAmount"]
                #calculate PR,NTR,GTR
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Div_PR_PAF"]=1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Div_NTR_PAF"]=(k_PriceExT1 - (k_EventAmount*(k_TaxRate/100)*k_Fx_1))/k_PriceExT1                 
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Div_GTR_PAF"]=(k_PriceExT1 - (k_EventAmount*k_Fx_1))/k_PriceExT1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Div_NSAF"]=1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"SCR_GTR_NSAF"]=k_PriceExT1 / (k_PriceExT1 - (k_EventAmount*k_Fx_1))
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"SCR_NTR_NSAF"]=k_PriceExT1 / (k_PriceExT1 - (k_EventAmount*(k_TaxRate/100)*k_Fx_1))
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"SCR_PR_NSAF"]=1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"SCR_PAF"]=1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"AddC_GTR_CASH"]=k_EventAmount*k_Fx_1
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"AddC_NTR_CASH"]=k_EventAmount*k_Fx_1*(k_TaxRate/100)
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"AddC_PR_CASH"]=0
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Handled_on_PayDate"]="Yes"
                self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["KR","JP"])),"Multiple_Case"]="No"
                self.nd_final_combinedPay.to_csv("nd_final_combinedPay_1.csv")
                logA.info("Non Multiple Third Cash Dividend for pay date  calculation status: SUCCESS")
            else:
                logA.info("Non Multiple Third Cash Dividend for pay date cases calculation: NO RECORDS FOUND")
        except Exception as e:
            logA.error(e)
            logA.error("Third Cash Dividend on Paydate handling status: FAILED")
            
    def special_cash_dividend(self):
#        f_df=pd.DataFrame()
        """Calculation for special cash Dividend and similar kind of treatment"""
        try:
            """First Handling for non exceptional cases
               Second Handling for exceptional cases
               Third Handling for pay date exceptional cases"""
            #Exceptional cases will be handled the same as below
            logA.info("Non Multiple Special Cash Dividend for non exceptional cases Calculation is INITIATED")
            if (not self.sql_cash_div_ex_excep.empty) and (self.sql_cash_div_ex_excep.loc[(self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"])),"EventType"].count()>0):
#                logA.info("Inside Special Cash Dividend treatment for non exceptional")
                logA.info("Non Multiple Special Cash Dividend for non exceptional cases Calculation is INITIATED")
                s_EventAmount=self.fn_s_cash_ex_excep("Special Cash Dividend","EventAmount")
                s_PriceExT1=self.fn_s_cash_ex_excep("Special Cash Dividend","PriceExT1")
                s_FxExT1=self.fn_s_cash_ex_excep("Special Cash Dividend","FxExT1")
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Div_GTR_PAF"]=(s_PriceExT1 - ( s_EventAmount *s_FxExT1 )) / s_PriceExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Div_NTR_PAF"]=(s_PriceExT1 - ( s_EventAmount *s_FxExT1 )) / s_PriceExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Div_PR_PAF"]=(s_PriceExT1 -( s_EventAmount * s_FxExT1)) / s_PriceExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Div_NSAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"SCR_GTR_NSAF"]=(s_PriceExT1)/(s_EventAmount * s_FxExT1)
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"SCR_NTR_NSAF"]=(s_PriceExT1)/(s_EventAmount * s_FxExT1)
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"SCR_PR_NSAF"]=(s_PriceExT1)/(s_EventAmount * s_FxExT1)
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"SCR_PAF"]=1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"AddC_GTR_CASH"]=s_EventAmount*s_FxExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"AddC_NTR_CASH"]=s_EventAmount*s_FxExT1
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"AddC_PR_CASH"]=0
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Handled_on_PayDate"]="No"
                self.sql_cash_div_ex_excep.loc[self.sql_cash_div_ex_excep["EventType"].isin(["Special Cash Dividend"]),"Multiple_Case"]="No"
                logA.debug("Total No of special cash dividend(non exceptional cases): {0}".format(s_PriceExT1.count()))
                logA.debug("PriceExT1_{0}".format(s_PriceExT1))
                logA.debug("FxExT1_{0}".format(s_FxExT1))
                logA.debug("DividendAmount_{0}".format(s_EventAmount))
#                self.sql_cash_div_ex_excep.to_csv("sql_cash_div_ex_excep_2.csv")
                logA.info("Non Multiple Special Cash Dividend for non exceptional cases Calculation status: SUCCES")
            else:
                logA.info("Special Cash Dividend for non exceptional cases : NO RECORDS FOUND")
                pass
            #handling depends 
            if (not self.sql_cash_div_except.empty) and (self.sql_cash_div_except.loc[self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"]),"EventType"].count() > 0):
                logA.info("Inside Special Cash Dividend treatment for Exceptional cases")
                au_eventAmount=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"EventAmount"]
                au_PriceExT1=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"PriceExT1"]
                au_Fx_1=self.sql_cash_div_except.loc[(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"]))&(self.sql_cash_div_except["LocalCurrency"].isin(["AU"])),"FxExT1"]
                logA.debug("au_eventAmount= {}".format(au_eventAmount))
                logA.debug("au_PriceExT1= {}".format(au_PriceExT1))
                logA.debug("au_Fx_1= {}".format(au_Fx_1))
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Div_GTR_PAF"]=(au_PriceExT1-(au_eventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Div_NTR_PAF"]=(au_PriceExT1-(au_eventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Div_PR_PAF"]=(au_PriceExT1-(au_eventAmount*au_Fx_1))/au_PriceExT1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Div_NSAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"SCR_GTR_NSAF"]=(au_PriceExT1)/(au_eventAmount*au_Fx_1)
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"SCR_NTR_NSAF"]=(au_PriceExT1)/(au_eventAmount*au_Fx_1)
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"SCR_PR_NSAF"]=(au_PriceExT1)/(au_eventAmount*au_Fx_1)
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"SCR_PAF"]=1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"AddC_GTR_CASH"]=au_eventAmount*au_Fx_1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"AddC_NTR_CASH"]=au_eventAmount*au_Fx_1
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"AddC_PR_CASH"]=0
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Handled_on_PayDate"]="No"
                self.sql_cash_div_except.loc[self.sql_cash_div_except["LocalCurrency"].isin(["AU"])&(self.sql_cash_div_except["EventType"].isin(["Special Cash Dividend"])),"Multiple_Case"]="No"
                self.sql_cash_div_except.to_csv("sql_cash_div_except_2.csv")
            else:
                logA.info("Special Cash Dividend for exceptional cases : NO RECORDS FOUND")
                pass                         
            if (not self.nd_final_combinedPay.empty) and (self.nd_final_combinedPay.loc[(self.nd_final_combinedPay['LocalCurrency'].isin(["JP","KR"])) &(self.nd_final_combinedPay['EventType'].isin(['Special Cash Dividend'])),"EventType"].count() > 0):
                logA.info("Inside Special Cash Dividend treatment for Pay Date")
                jp_kr_PriceExT1=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])),"PayDatePriceT1"]
                jp_kr_eventAmount=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])),"EventAmount"]
                jp_kr_fx_1=au_Fx_1=self.nd_final_combinedPay.loc[(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"]))&(self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])),"PayDateFxT1"]
                logA.debug("jp_kr_PriceExT1= {}".format(jp_kr_PriceExT1))
                logA.debug("jp_kr_eventAmount= {}".format(jp_kr_eventAmount))
                logA.debug("jp_kr_fx_1= {}".format(jp_kr_fx_1))
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Div_GTR_PAF"]=(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))/jp_kr_PriceExT1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Div_NTR_PAF"]=(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))/jp_kr_PriceExT1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Div_PR_PAF"]=(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))/jp_kr_PriceExT1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Div_NSAF"]=1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"SCR_GTR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"SCR_NTR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"SCR_PR_NSAF"]=jp_kr_PriceExT1/(jp_kr_PriceExT1-(jp_kr_eventAmount*jp_kr_fx_1))
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"SCR_PAF"]=1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"AddC_GTR_CASH"]=jp_kr_eventAmount*jp_kr_fx_1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"AddC_NTR_CASH"]=jp_kr_eventAmount*jp_kr_fx_1
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"AddC_PR_CASH"]=0
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Handled_on_PayDate"]="Yes"
                self.nd_final_combinedPay.loc[self.nd_final_combinedPay["LocalCurrency"].isin(["JP","KR"])&(self.nd_final_combinedPay["EventType"].isin(["Special Cash Dividend"])),"Multiple_Case"]="No"
#                self.nd_final_combinedPay.to_csv("nd_final_combinedPay_2.csv")
                logA.info("Non multiple Special Cash Dividend for exceptional cases Calculation status: SUCCESS")
            else:
                logA.info("Non multiple Special Cash Dividend for exceptional cases for PayDate : NO RECORDS FOUND")
                pass
#            f_df=f_df.append(self.sql_cash_div_ex_excep,sort=False)
#            f_df=f_df.append(self.sql_cash_div_except,sort=False)
##                a=obj_process.sql_cash_div_ex_excep.append(obj_process.sql_cash_div_except)
#            f_df=f_df.append(self.nd_final_combinedPay,sort=False)
#            f_df.to_csv("let_me_check_special_cash.csv")
        except Exception as e:
            logA.error(e)
            logA.error("Non multiple Special Cash Dividend for exceptional cases Calculation status: FAILED")
#            pass
    def stock_dividend(self):
        try:
            logA.info("Non multiple Stock Dividend Calculation is INITIATED")
            new_shares=self.sql_others.loc[self.sql_data["EventType"].isin(["Stock Dividend"]),"TermNewShares"]
            old_shares=self.sql_others.loc[self.sql_data["EventType"].isin(["Stock Dividend"]),"TermOldShares"]
            mst=new_shares/old_shares
#            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Dividend"]),"m"]=mst
            self.sql_others.loc[self.sql_others["EventType"].isin(['Stock Dividend']),"Div_PAF"]=1/(1+mst)
            self.sql_others.loc[self.sql_others["EventType"].isin(['Stock Dividend']),"Div_NSAF"]=1+mst
            self.sql_others.loc[self.sql_others["EventType"].isin(['Stock Dividend']),"SCR_NSAF"]=1+mst
            self.sql_others.loc[self.sql_others["EventType"].isin(['Stock Dividend']),"Handled_on_PayDate"]="No"
            self.sql_others.loc[self.sql_others["EventType"].isin(['Stock Dividend']),"Multiple_Case"]="No"
#            self.sql_others.to_csv("others.csv")
            logA.info("Non multiple Stock Dividend Calculation status: SUCCESS")
        except Exception as e:
            logA.error(e)
            logA.error("Non multiple Stock Dividend Calculation status: FAILED")
            pass
    def stock_split(self):
        try:
            logA.info("Non multiple Stock Dividend Calculation is INITIATED")
            new_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"TermNewShares"]
            old_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"TermOldShares"]
            ms=new_shares/old_shares
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"Div_PAF"]=1/ms
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"Div_NSAF"]=ms
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"SCR_NSAF"]=ms
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"Handled_on_PayDate"]="No"
            self.sql_others.loc[self.sql_others["EventType"].isin(["Stock Split"]),"Multiple_Case"]="No"
            logA.error("Non multiple Stock Dividend Calculation status: SUCCESS")
#            self.sql_others.to_csv("others.csv")
        except Exception as e:
            logA.error(e)
            logA.error("Non multiple Stock Dividend Calculation status: FAILED")
            pass
    def rights_issue(self):
        try:
            logA.info("Non multiple Rights Issue Calculation is INITIATED")
            subs_price=self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"OfferPrice"]
            price_ex_1=self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"PriceExT1"]
            new_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"TermNewShares"]
            old_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"TermOldShares"]
            mr=new_shares/old_shares
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"Div_PAF"]=(price_ex_1-(mr*subs_price))/price_ex_1
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"Div_NSAF"]=1-mr
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"SCR_NSAF"]=(price_ex_1*(1+mr))/(price_ex_1+subs_price*mr)
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"Handled_on_PayDate"]="No"
            self.sql_others.loc[self.sql_others["EventType"].isin(["Rights Issue"]),"Multiple_Case"]="No"
            logA.info("Non multiple Rights Issue Calculation status : SUCCESS ")
        except Exception as e:
            logA.error(e)
            logA.error("Non multiple Rights Issue Calculation status : FAILED")
            pass
#    def buy_back(self):
#        try:
#            logA.info("Rights Issue Calculation is INITIATED")
#            buybk_price=self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"OfferPrice"]
#            price_ex_1=self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"PriceExT1"]
#            new_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"TermNewShares"]
#            old_shares=self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"TermOldShares"]
#            m=new_shares/old_shares
#            self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"PAF"]=(price_ex_1-(m*buybk_price))/price_ex_1
#            self.sql_others.loc[self.sql_others["EventType"].isin(["Buyback"]),"NSAF"]=1-m
#            return self.sql_others
#        except Exception as e:
#            logA.error(e)
#            logA.error("Rights Issue Calculation has FAILED")
#            pass
    def spin_off(self):
        try:
            logA.info("Spin off Calculation is INITIATED")
            PriceExT1=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"PriceExT1"]
            cash=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"SpunOffCash"]
            spun_entity_openprices=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"OfferPrice"]
            newshares=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"TermNewShares"]
            oldshares=self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"TermOldShares"]
            mso=newshares/oldshares
            self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"Div_PAF"]=(PriceExT1-cash-mso*spun_entity_openprices)/PriceExT1
            self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"Div_NSAF"]=1
            self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"SCR_NSAF"]=1
            self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"Handled_on_PayDate"]="No"
            self.sql_others.loc[self.sql_others["EventType"].isin(["Spin Off"]),"Multiple_Case"]="No"
#            self.sql_others.to_csv("final_others.csv")
        except Exception as e:
            logA.error(e)
            logA.error("Spin off Calculation has FAILED")
    def nd_event_types(self):
        nd_event_types=list(set(self.nd_final_combinedEx["EventType"]))
        nd_event_types_1=list(set(self.nd_final_combinedPay["EventType"]))
        final_types=list(set().union(nd_event_types,nd_event_types_1))
        return final_types        
        
#if __name__=="__main__":
#    check=rule_divisor()
#    check.multi_CA_handler()
#    check.cash_dividend()
#    check.special_cash_dividend()
#    check.stock_dividend()
#    check.stock_split()
#    check.rights_issue()
#    check.spin_off()
